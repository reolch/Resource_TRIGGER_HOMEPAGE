import Header from "@/components/header"
import Footer from "@/components/footer"
import CtaBanner from "@/components/cta-banner"
import Image from "next/image"

export default function PricePage() {
  return (
    <main className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Section */}
      <section className="relative h-[400px] lg:h-[500px] overflow-hidden">
        <Image src="/images/design-mode/price-page-banner.avif" alt="料金表" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-black/30" />
        <div className="relative z-10 flex h-full flex-col items-center justify-center text-white">
          <p className="mb-2 text-base lg:text-lg tracking-widest">料金表</p>
          <h1 className="text-4xl lg:text-5xl font-light tracking-[0.3em]">PRICE</h1>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 z-20 hidden -translate-y-1/2 flex-col lg:flex">
          <a
            href="/trial"
            className="flex items-center justify-center bg-[#7b8d7b] text-white transition-opacity hover:opacity-80"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
            }}
          >
            <span className="text-sm tracking-widest">無料体験レッスン</span>
          </a>
          <a
            href="/campaign"
            className="flex items-center justify-center bg-[#e8a598] text-white transition-opacity hover:opacity-80"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
            }}
          >
            <span className="text-sm tracking-widest">キャンペーン</span>
          </a>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-20">
        <div className="mx-auto max-w-[930px] px-4 text-center">
          <h2 className="mb-16 text-xl leading-relaxed text-[#666] md:text-2xl">
            あなたのライフスタイルに合わせて
            <br />
            様々なプログラムをご用意
          </h2>

          {/* Entry Price */}
          <div className="mb-16 overflow-hidden border border-gray-200">
            <div className="relative h-[200px] overflow-hidden">
              <Image src="/images/design-mode/price-page-0.jpg" alt="入会金" fill className="object-cover" />
              <div className="absolute inset-0 bg-black/40" />
              <div className="relative z-10 flex h-full items-center justify-center">
                <h3 className="text-2xl font-light tracking-widest text-white">入会金</h3>
              </div>
            </div>
            <div className="bg-white p-8">
              <div className="flex items-center justify-between border-t border-gray-200 pt-6">
                <span className="text-[#333]">会員登録費用</span>
                <span className="text-[#333]">22,000円</span>
              </div>
            </div>
          </div>

          {/* Trial Lesson Card */}
          <div className="mb-16 overflow-hidden border border-gray-200">
            <div className="relative h-[200px] overflow-hidden">
              <Image src="/images/design-mode/price-page-1.jpg" alt="体験レッスン" fill className="object-cover" />
              <div className="absolute inset-0 bg-black/40" />
              <div className="relative z-10 flex h-full items-center justify-center">
                <h3 className="text-2xl font-light tracking-widest text-white">まずはお試し体験コース</h3>
              </div>
            </div>
            <div className="bg-white p-8">
              <p className="mb-2 text-[#333]">まずは体験レッスンでスタジオの雰囲気を気軽にチェックしてみてください。</p>
              <p className="mb-6 text-[#333]"></p>
              <div className="flex items-center justify-between border-t border-gray-200 pt-6">
                <span className="text-[#333]">初回体験</span>
                <span className="text-[#333]">
                  <span className="mr-2 text-gray-400 line-through">5,500円</span>→ 2,980円
                </span>
              </div>
            </div>
          </div>

          {/* All in One Course */}
          <div className="mb-16 overflow-hidden border border-gray-200">
            <div className="relative h-[200px] overflow-hidden">
              <Image
                src="/images/design-mode/price-page-2.jpg"
                alt="オールインワンコース"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-black/40" />
              <div className="relative z-10 flex h-full items-center justify-center">
                <h3 className="text-2xl font-light tracking-widest text-white">オールインワンコース</h3>
              </div>
            </div>
            <div className="bg-white p-8">
              <p className="mb-2 text-[#333]">TRIGGERの最高峰コース短期集中で身体を理想へ導きたい方へ。</p>
              <p className="mb-6 text-[#333]"></p>
              <PriceTable
                title=""
                bgColor="#7b8d7b"
                items={[
                  { name: "GOLD（2ヶ月）", price: "¥220.000 (税込）" },
                  { name: "PLATINUM（3ヶ月）", price: "¥264.000 (税込）" },
                  { name: "DIAMOND（4ヶ月）", price: "¥418.000 (税込）" },
                ]}
              />
            </div>
          </div>

          {/* Life Fit Course */}
          <div className="mb-16 overflow-hidden border border-gray-200">
            <div className="relative h-[200px] overflow-hidden">
              <Image
                src="/images/design-mode/price-page-3.jpg"
                alt="ライフフィットコース（月額制）"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-black/40" />
              <div className="relative z-10 flex h-full items-center justify-center">
                <h3 className="text-2xl font-light tracking-widest text-white">ライフフィットコース（月額制）</h3>
              </div>
            </div>
            <div className="bg-white p-8">
              <p className="mb-2 text-[#333]">月額制で長期で通いたい方へ</p>
              <p className="mb-6 text-[#333]"></p>
              <PriceTable title="" bgColor="#7b8d7b" items={[{ name: "月4回", price: "¥22,000 (税込）" }]} />
            </div>
          </div>

          {/* Hybrid Course */}
          <div className="mb-16 overflow-hidden border border-gray-200">
            <div className="relative h-[200px] overflow-hidden">
              <Image
                src="/images/design-mode/price-page-4.jpg"
                alt="ハイブリッドコース（月額制）"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-black/40" />
              <div className="relative z-10 flex h-full items-center justify-center">
                <h3 className="text-2xl font-light tracking-widest text-white">ハイブリッドコース（月額制）</h3>
              </div>
            </div>
            <div className="bg-white p-8">
              <p className="mb-2 text-[#333]">鍛える×整えるを実現。至福のコース</p>
              <p className="mb-6 text-[#333]"></p>
              <PriceTable title="" bgColor="#7b8d7b" items={[{ name: "月2回", price: "¥22,000 (税込）" }]} />
            </div>
          </div>

          {/* Golfer Course */}
          <div className="mb-16 overflow-hidden border border-gray-200">
            <div className="relative h-[200px] overflow-hidden">
              <Image
                src="/images/design-mode/price-page-5.jpg"
                alt="ゴルファー飛距離アップコース（１コマ30分）"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-black/40" />
              <div className="relative z-10 flex h-full items-center justify-center">
                <h3 className="text-2xl font-light tracking-widest text-white">
                  ゴルファー飛距離アップコース（１コマ30分）
                </h3>
              </div>
            </div>
            <div className="bg-white p-8">
              <p className="mb-2 text-[#333]">プロ〜アマまで通う本格トレーニング（学生は要相談）</p>
              <p className="mb-6 text-[#333]"></p>
              <PriceTable title="" bgColor="#7b8d7b" items={[{ name: "4回券", price: "¥22,000 (税込）" }]} />
            </div>
          </div>

          {/* Estehetic Course */}
          <div className="mb-16 overflow-hidden border border-gray-200">
            <div className="relative h-[200px] overflow-hidden">
              <Image
                src="/images/design-mode/price-page-6.jpg"
                alt="脂肪燃焼痩身エステ
"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-black/40" />
              <div className="relative z-10 flex h-full items-center justify-center">
                <h3 className="text-2xl font-light tracking-widest text-white">脂肪燃焼痩身エステ</h3>
              </div>
            </div>
            <div className="bg-white p-8">
              <p className="mb-2 text-[#333]">脂肪燃焼を促進する最新の痩身マシン</p>
              <p className="mb-6 text-[#333]"></p>
              <PriceTable
                title=""
                bgColor="#7b8d7b"
                items={[
                  { name: "30分（半身）4回券", price: "¥26.400" },
                  { name: "60分（全身）4回券", price: "¥44.000" },
                ]}
              />
            </div>
          </div>

          {/* Mat Pilates */}
          {/* <PriceTable
            title="マットピラティス"
            bgColor="#a08060"
            items={[
              { name: "4回チケット", price: "10,000円（2,500円／回）" },
              { name: "6回チケット", price: "13,200円（2,200円／回）" },
              { name: "10回チケット", price: "20,000円（2,000円／回）" },
              { name: "追加チケット", price: "3,000円" },
            ]}
          /> */}

          {/* Other Services */}
          {/*
            <div className="mb-16">
              <div className="bg-[#3d4a4f] py-4">
                <h3 className="text-lg tracking-widest text-white">その他サービス</h3>
              </div>
              <div className="border border-t-0 border-gray-200">
                {[
                  { name: "レンタルマット1回", price: "800円" },
                  { name: "レンタルマット1カ月", price: "5,000円" },
                  { name: "レンタルウェア（上下セット）", price: "1,000円" },
                ].map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between border-b border-gray-200 px-6 py-4 last:border-b-0"
                  >
                    <span className="text-[#333]">{item.name}</span>
                    <span className="text-[#333]">{item.price}</span>
                  </div>
                ))}
              </div>
            </div>
          */}

          {/* Note */}
          <p className="mb-16 text-left text-sm leading-relaxed text-[#666]">
            ＊チケットの有効期限は毎月1日（入会月においては入会日）から末日までになります。追加チケットの有効期限は購入日から当月末日までとします。期間経過後、翌月にチケットを持ち越すことはできません。
          </p>
        </div>
      </section>

      <CtaBanner />
      <Footer />
    </main>
  )
}

function PriceTable({
  title,
  bgColor,
  items,
}: {
  title: string
  bgColor: string
  items: { name: string; price: string }[]
}) {
  return (
    <div className="mb-10">
      <div style={{ backgroundColor: bgColor }} className="py-4">
        <h3 className="text-lg tracking-widest text-white">{title}</h3>
      </div>
      <div className="border border-t-0 border-gray-200">
        {items.map((item, index) => (
          <div
            key={index}
            className="flex items-center justify-between border-b border-gray-200 px-6 py-4 last:border-b-0"
          >
            <span className="text-[#333]">{item.name}</span>
            <span className="text-[#333]">{item.price}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
