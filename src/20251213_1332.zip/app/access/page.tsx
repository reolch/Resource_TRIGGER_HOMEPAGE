import Header from "@/components/header"
import Footer from "@/components/footer"
import Image from "next/image"
import Link from "next/link"

export default function AccessPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />

      <section className="relative h-[400px] lg:h-[500px] overflow-hidden">
        <Image src="/access-hero-gym-exterior.jpg" alt="TRIGGER アクセス" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center">
          <p className="text-[13px] tracking-[0.2em] mb-3">アクセス</p>
          <h1 className="text-4xl lg:text-5xl tracking-[0.15em] font-light">ACCESS</h1>
        </div>
      </section>

      <nav className="bg-[#f8f8f6] px-6 py-4">
        <div className="max-w-[1200px] mx-auto">
          <ol className="flex items-center gap-2 text-[13px] text-[#666]">
            <li>
              <Link href="/" className="hover:text-[#c4a47c] transition-colors">
                HOME
              </Link>
            </li>
            <li>/</li>
            <li className="text-[#c4a47c]">ACCESS</li>
          </ol>
        </div>
      </nav>

      <section className="py-20 md:py-28 px-6">
        <div className="max-w-[1000px] mx-auto">
          {/* Map */}
          <div className="mb-16">
            <div className="relative w-full h-[400px] md:h-[500px] bg-[#e5e5e5]">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3392.7516752767644!2d131.4174687!3d31.7743924!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x353fb26c9c9d3b5d%3A0x1234567890abcdef!2sTRIGGER!5e0!3m2!1sja!2sjp!4v1699000000000!5m2!1sja!2sjp"
                className="w-full h-full border-0"
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>

          {/* Info Table */}
          <div className="border border-[#ddd]">
            <table className="w-full">
              <tbody className="divide-y divide-[#ddd]">
                <tr>
                  <td className="px-6 py-5 text-[14px] text-[#666] bg-[#f8f8f6] w-1/4">項目</td>
                  <td className="px-6 py-5 text-[14px] text-[#333]">詳細</td>
                </tr>
                <tr>
                  <td className="px-6 py-5 text-[14px] text-[#666] bg-[#f8f8f6]">住所</td>
                  <td className="px-6 py-5 text-[14px] text-[#333]">
                    〒880-0055
                    <br />
                    宮崎県宮崎市南花ケ島町１３２−１
                    <br />
                    川村ビル １F
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-5 text-[14px] text-[#666] bg-[#f8f8f6]">アクセス・道案内</td>
                  <td className="px-6 py-5 text-[14px] text-[#333]">
                    宮崎神宮駅から徒歩でアクセスディスクを経由してすぐにあります
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-5 text-[14px] text-[#666] bg-[#f8f8f6]">営業時間</td>
                  <td className="px-6 py-5 text-[14px] text-[#333]">
                    [月・水] 10:00〜20:00
                    <br />
                    [土] 9:00〜14:30
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-5 text-[14px] text-[#666] bg-[#f8f8f6]">定休日</td>
                  <td className="px-6 py-5 text-[14px] text-[#333]">日・祝、第五週目、お盆、ゴールデンウィーク</td>
                </tr>
                <tr>
                  <td className="px-6 py-5 text-[14px] text-[#666] bg-[#f8f8f6]">支払い方法</td>
                  <td className="px-6 py-5 text-[14px] text-[#333]">Visa／Mastercard／JCB／American Express</td>
                </tr>
                <tr>
                  <td className="px-6 py-5 text-[14px] text-[#666] bg-[#f8f8f6]">SNS</td>
                  <td className="px-6 py-5 text-[14px] text-[#333]">
                    <div className="flex gap-4">
                      <Link
                        href="https://www.instagram.com/trigger_myzk2023/"
                        target="_blank"
                        className="hover:text-[#c4a47c] transition-colors"
                      >
                        Instagram(DM)
                      </Link>
                      <Link href="#" className="hover:text-[#c4a47c] transition-colors">
                        公式ライン
                      </Link>
                      <Link href="#" className="hover:text-[#c4a47c] transition-colors">
                        ホットペッパー
                      </Link>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-5 text-[14px] text-[#666] bg-[#f8f8f6]">スタッフ数</td>
                  <td className="px-6 py-5 text-[14px] text-[#333]">2人</td>
                </tr>
                <tr>
                  <td className="px-6 py-5 text-[14px] text-[#666] bg-[#f8f8f6]">駐車場</td>
                  <td className="px-6 py-5 text-[14px] text-[#333]">あり</td>
                </tr>
                <tr>
                  <td className="px-6 py-5 text-[14px] text-[#666] bg-[#f8f8f6]">備考</td>
                  <td className="px-6 py-5 text-[14px] text-[#333]">
                    お子様連れOK※
                    <br />
                    ※予約時にご確認とお伝えください
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Google Maps Link */}
          <div className="mt-8 text-center">
            <Link
              href="https://maps.google.com"
              target="_blank"
              className="inline-flex items-center gap-2 text-[14px] text-[#333] border border-[#333] px-8 py-3 hover:bg-[#333] hover:text-white transition-colors"
            >
              Google Mapで見る
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
