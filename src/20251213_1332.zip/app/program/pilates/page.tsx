import Header from "@/components/header"
import Footer from "@/components/footer"
import CtaBanner from "@/components/cta-banner"
import { ChevronRight } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function PilatesPage() {
  const subPrograms = [
    { id: "mat-pilates", name: "マットピラティス" },
    { id: "machine-pilates", name: "マシンピラティス" },
    { id: "personal-lesson", name: "パーソナルレッスン" },
  ]

  return (
    <main className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Banner */}
      <section className="relative h-[50vh] min-h-[400px]">
        <Image src="/pilates-hero-woman-reformer.jpg" alt="PILATES" fill className="object-cover" />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center">
          <p className="text-sm tracking-[0.3em] mb-2">ピラティス</p>
          <h1 className="text-4xl md:text-5xl font-light tracking-[0.2em]">PILATES</h1>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden lg:flex flex-col z-10">
          <Link
            href="/trial"
            className="flex items-center justify-center bg-[#7b8d7b] text-white text-sm tracking-wider hover:opacity-90 transition-opacity"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            無料体験レッスン
          </Link>
          <Link
            href="/reserve"
            className="flex items-center justify-center bg-[#e8b4a8] text-white text-sm tracking-wider hover:opacity-90 transition-opacity"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            レッスン予約
          </Link>
        </div>
      </section>

      {/* Breadcrumb */}
      <div className="bg-white py-4">
        <div className="max-w-[1200px] mx-auto px-6">
          <nav className="flex items-center gap-2 text-sm text-gray-500">
            <Link href="/" className="hover:text-gray-800">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
                />
              </svg>
            </Link>
            <ChevronRight className="w-3 h-3" />
            <Link href="/program" className="hover:text-gray-800">
              プログラム
            </Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-[#a08060]">PILATES</span>
          </nav>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="bg-[#a08060]">
        <div className="max-w-[1200px] mx-auto">
          <nav className="flex justify-center">
            {subPrograms.map((program) => (
              <a
                key={program.id}
                href={`#${program.id}`}
                className="text-white text-sm py-4 px-8 hover:bg-[#8f7050] transition-colors border-r border-[#8f7050] last:border-r-0"
              >
                {program.name}
              </a>
            ))}
          </nav>
        </div>
      </div>

      {/* Introduction */}
      <section className="py-20">
        <div className="max-w-[800px] mx-auto px-6 text-center">
          <p className="text-gray-600 leading-[2] text-[15px]">
            ピラティスは、体幹（コア）を鍛えながら姿勢を整え、しなやかで強い体を作ることを目的としています。ピラティスの大きな魅力は、「体の内側から鍛えられる」こと。深い呼吸とともにインナーマッスルを意識して動かすことで、筋力・柔軟性・バランス感覚を向上させ、日常生活の姿勢改善や運動パフォーマンスの向上につながります。
          </p>
        </div>
      </section>

      {/* Mat Pilates Section */}
      <section id="mat-pilates" className="py-16">
        <div className="max-w-[800px] mx-auto px-6">
          <div className="text-center mb-12">
            <p className="text-[#c4a47c] text-sm tracking-wider mb-2">マットピラティス</p>
            <h2 className="text-2xl md:text-3xl font-light text-gray-800 relative inline-block pb-4">
              ピラティスの基本を学ぶ
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-[1px] bg-[#c4a47c]"></span>
            </h2>
          </div>
          <p className="text-gray-600 leading-[2] text-[15px] mb-10">
            マットピラティスは、専用のマットを使用して行うピラティスの基本的なプログラムです。自分の体重を利用してコア（体幹）を強化し、姿勢の改善や柔軟性の向上を目指します。初心者の方でも無理なく取り組めるよう、シンプルな動きからスタートし、徐々にレベルアップできるように構成されています。
          </p>
          <div>
            <Image
              src="/pilates-mat-pilates-woman.jpg"
              alt="マットピラティス"
              width={800}
              height={500}
              className="w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* Machine Pilates Section */}
      <section id="machine-pilates" className="py-16">
        <div className="max-w-[800px] mx-auto px-6">
          <div className="text-center mb-12">
            <p className="text-[#c4a47c] text-sm tracking-wider mb-2">マシンピラティス</p>
            <h2 className="text-2xl md:text-3xl font-light text-gray-800 relative inline-block pb-4">
              専用のマシンで無理なくエクササイズ
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-[1px] bg-[#c4a47c]"></span>
            </h2>
          </div>
          <p className="text-gray-600 leading-[2] text-[15px] mb-10">
            マシンピラティスは、専用のピラティスマシン（リフォーマーやキャデラックなど）を使用して行うプログラムで、マットピラティスと比べてより効果的に筋肉を鍛え、身体のバランスを整えることができます。マシンにはスプリング（バネ）の抵抗があり、動きのサポートをしながらも、負荷を調整することで、個々の体力や柔軟性に応じたトレーニングが可能になります。
          </p>
          <div className="mb-10">
            <Image
              src="/pilates-machine-reformer-woman.jpg"
              alt="マシンピラティス"
              width={800}
              height={500}
              className="w-full h-auto"
            />
          </div>
          <p className="text-gray-600 leading-[2] text-[15px] mb-10">
            さらに、マシンピラティスは全身の筋肉をバランスよく鍛えることができるため、引き締まった身体を目指したい方にも適しています。特に、インナーマッスルを意識した動きを重視することで、ウエストやヒップラインの引き締め、体のラインの美しさを追求することが可能です。初心者の方でも、インストラクターが丁寧にサポートしますので、安心してご参加ください。
          </p>
          <div>
            <Image
              src="/pilates-machine-class-women.jpg"
              alt="マシンピラティスクラス"
              width={800}
              height={500}
              className="w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* Personal Lesson Section */}
      <section id="personal-lesson" className="py-16">
        <div className="max-w-[800px] mx-auto px-6">
          <div className="text-center mb-12">
            <p className="text-[#c4a47c] text-sm tracking-wider mb-2">パーソナルレッスン</p>
            <h2 className="text-2xl md:text-3xl font-light text-gray-800 relative inline-block pb-4">
              マンツーマンで行う個別レッスン
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-[1px] bg-[#c4a47c]"></span>
            </h2>
          </div>
          <p className="text-gray-600 leading-[2] text-[15px] mb-10">
            個々の目的や体力レベル、身体の特徴に合わせたオーダーメイドのレッスンを提供するため、より効果的にピラティスの効果を実感できます。グループレッスンでは難しい細かい動きの調整や、特定の部位を重点的に鍛えることができるため、よりパーソナライズされたトレーニングを求める方に最適です。
          </p>
          <div>
            <Image
              src="/pilates-personal-lesson-instructor.jpg"
              alt="パーソナルレッスン"
              width={800}
              height={500}
              className="w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* Price Info */}
      <section className="py-16 bg-[#f9f9f7]">
        <div className="max-w-[800px] mx-auto px-6 text-center">
          <p className="text-gray-600 leading-[2] text-[15px] mb-8">
            レッスンは、わかりやすいチケット制です。ピラティスやヨガのグループレッスン・パーソナルレッスンに通い放題であなたの好きな時間にいつでもご予約いただけます。
          </p>
          <Link
            href="/price"
            className="inline-block bg-gray-900 text-white px-12 py-4 text-sm tracking-wider hover:bg-gray-800 transition-colors"
          >
            料金表はこちら
          </Link>
        </div>
      </section>

      <CtaBanner />
      <Footer />
    </main>
  )
}
