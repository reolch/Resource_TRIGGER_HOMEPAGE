import Header from "@/components/header"
import Footer from "@/components/footer"
import CTABanner from "@/components/cta-banner"
import Link from "next/link"
import Image from "next/image"

const subPrograms = [
  {
    id: "diet",
    title: "ダイエット",
    subtitle: "健康的に痩せる",
    description:
      "お客様一人ひとりの目標や体質に合わせたオーダーメイドのダイエットプログラムをご提案。無理な食事制限ではなく、適切な栄養バランスと効果的なトレーニングを組み合わせることで、リバウンドしにくい健康的な体づくりをサポートします。",
    image: "/personal-training-diet-weight-loss-gym.jpg",
  },
  {
    id: "muscle",
    title: "筋力アップ",
    subtitle: "理想のボディメイク",
    description:
      "筋肉量を増やし、基礎代謝を高めることで太りにくい体質へ。正しいフォームと適切な負荷設定で、効率的に筋力アップを目指します。初心者の方でも安心して取り組めるプログラムです。",
    image: "/muscle-training-bodybuilding-gym-workout.jpg",
  },
  {
    id: "posture",
    title: "姿勢改善",
    subtitle: "美しい姿勢を手に入れる",
    description:
      "デスクワークや日常生活で崩れがちな姿勢を、専門的なトレーニングで改善。肩こりや腰痛の予防・改善にも効果的です。姿勢が良くなることで見た目の印象も大きく変わります。",
    image: "/posture-correction-training-gym-fitness.jpg",
  },
]

export default function PersonalGymPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Banner */}
      <section className="relative h-[400px] lg:h-[500px]">
        <Image src="/personal-gym-training-session-professional.jpg" alt="パーソナルジム" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-[#3d4a4f]/50" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center">
          <p className="text-sm tracking-[0.3em] mb-2">パーソナルジム</p>
          <h1 className="text-4xl lg:text-5xl tracking-[0.2em] font-light">PERSONAL GYM</h1>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden lg:flex flex-col z-20">
          <Link
            href="/trial"
            className="flex items-center justify-center text-white text-sm tracking-widest bg-[#6b7c7f] hover:bg-[#5a6a6e] transition-colors"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            無料体験レッスン
          </Link>
          <Link
            href="/campaign"
            className="flex items-center justify-center text-white text-sm tracking-widest bg-[#e8a598] hover:bg-[#d99588] transition-colors"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            キャンペーン
          </Link>
        </div>
      </section>

      {/* Breadcrumb */}
      <div className="bg-[#f8f8f6] py-3 px-4">
        <div className="max-w-[1200px] mx-auto">
          <nav className="text-xs text-[#888]">
            <Link href="/" className="hover:text-[#c4a47c]">
              ホーム
            </Link>
            <span className="mx-2">/</span>
            <Link href="/program" className="hover:text-[#c4a47c]">
              プログラム
            </Link>
            <span className="mx-2">/</span>
            <span className="text-[#3d4a4f]">パーソナルジム</span>
          </nav>
        </div>
      </div>

      {/* Intro Section */}
      <section className="py-20 lg:py-28 px-4">
        <div className="max-w-[930px] mx-auto text-center">
          <p className="text-[#c4a47c] text-lg tracking-[0.3em] mb-4">あなた専用のトレーニング</p>
          <h2 className="text-2xl lg:text-3xl text-[#3d4a4f] tracking-[0.1em] mb-8 leading-relaxed">
            プロトレーナーが多様なニーズに応える
            <br />
            オリジナルメニューをご提案
          </h2>
          <p className="text-[#666] leading-relaxed text-sm lg:text-base hidden lg:block">
            TRIGGERのパーソナルジムでは、お客様一人ひとりの目標・体質・ライフスタイルに合わせた完全オーダーメイドのトレーニングプログラムをご提供しています。
            <br />
            ダイエット、筋力アップ、姿勢改善など、様々なニーズに対応。経験豊富なプロトレーナーが、あなたの理想の体づくりを全力でサポートします。
            <br />
            初心者の方でも安心してスタートできる環境を整えておりますので、お気軽にご相談ください。
          </p>
          <p className="text-[#666] leading-relaxed text-sm lg:hidden">
            お客様一人ひとりの目標・体質に合わせた完全オーダーメイドのトレーニングプログラムをご提供。プロトレーナーが理想の体づくりを全力でサポートします。
          </p>
        </div>
      </section>

      {/* Sub Programs */}
      <section className="pb-20 lg:pb-28">
        {subPrograms.map((program, index) => (
          <div
            key={program.id}
            id={program.id}
            className={`flex flex-col ${index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"}`}
          >
            <div className="relative w-full lg:w-1/2 h-[300px] lg:h-[500px]">
              <Image src={program.image || "/placeholder.svg"} alt={program.title} fill className="object-cover" />
            </div>
            <div className="w-full lg:w-1/2 flex items-center justify-center p-8 lg:p-16 bg-[#f8f8f6]">
              <div className="max-w-[450px]">
                <p className="text-[#c4a47c] text-sm tracking-[0.2em] mb-2">{program.subtitle}</p>
                <h3 className="text-2xl lg:text-3xl text-[#3d4a4f] tracking-[0.1em] mb-6">{program.title}</h3>
                <p className="text-[#666] text-sm lg:text-base leading-relaxed">{program.description}</p>
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Price Link Section */}
      <section className="py-16 bg-[#3d4a4f] text-center">
        <p className="text-white/80 text-sm mb-4">料金について詳しく知りたい方はこちら</p>
        <Link
          href="/price"
          className="inline-flex items-center justify-center gap-2 px-12 py-4 bg-white text-[#3d4a4f] text-sm tracking-wider hover:bg-[#f8f8f6] transition-colors"
        >
          料金表を見る
        </Link>
      </section>

      <CTABanner />
      <Footer />
    </div>
  )
}
