"use client"

import Image from "next/image"
import { useState } from "react"
import { ChevronDown } from "lucide-react"
import Footer from "@/components/footer"
import Header from "@/components/header"
import { CtaBanner } from "@/components/cta-banner"

interface FAQItem {
  question: string
  answer: string
}

const faqData: Record<string, FAQItem[]> = {
  payment: [
    {
      question: "返金はできますか？",
      answer: "原則返金は行なっておりません。また会費の未払いなどにつきましては、法的措置の対象とさせていただきます",
    },
    {
      question: "お支払いについて",
      answer:
        "お支払いは短期コースだと、現金一括、またはカード払いとなります。カードの分割はお客様自身の分割機能にて設定していただきます。継続コースはクレジットカードの引き落としのみになります。",
    },
  ],
  cancellation: [
    {
      question: "初回予約の日程変更は可能でしょうか？",
      answer:
        "初回のお客様については原則２回までの変更となります。３回以上続く場合は、そのつもりでなくとも貴重な枠が潰れるため迷惑行為とし、施設のご予約を制限させていただきます。初回のご予約はなるべくお日にちのご移動がないようお努めくださいますようお願いしております。",
    },
    {
      question: "無断キャンセルは消化でしょうか？",
      answer:
        "無断キャンセルは理由を問わず消化扱いとなります。ご予約をお断りしたお客様もあったり、営業損失が出てしまうので、心苦しいですがご了承くださいませ。",
    },
    {
      question: "当日キャンセルはできますか？",
      answer:
        "TRIGGERでは当日キャンセル1時間前までは振替が可能です。しかし、故意的な直前キャンセルは利用停止処分になる為、キャンセルのないようお努めください。",
    },
  ],
  gym: [
    {
      question: "アフターケアはありますか？",
      answer:
        "宮崎市のTRIGGERではコース終了後も月額制コースでリーズナブルな価格で継続が可能となります。宮崎市のパーソナルジムの中でも圧倒的アフターフォローの強さを誇ります。",
    },
    {
      question: "リバウンドはしますか？",
      answer:
        "たしかにダイエットした後にリバウンドしたというお声はよく聞きますね、、、リバウンドの原因はジムの継続が難しいことが一番です。宮崎市のTRIGGERでは生活習慣の見直しを行い、無理のないダイエットと太りづらい体質づくりを実施しております。正しい知識をお届けし、続けやすい価格設定を実現しています。",
    },
    {
      question: "効果が現れるまでどれくらいかかりますか？",
      answer:
        "多くの方が2〜4週間ほどで変化を実感します。宮崎市のTRIGGERでは、目的に合わせたパーソナルトレーニングを行うため、姿勢改善・引き締め・体力向上などは比較的早く結果が出やすいのが特徴です。",
    },
    {
      question: "トレーニングはキツいですか？",
      answer:
        "きつすぎるトレーニングは行いません。宮崎市のTRIGGERでは、体力に合わせた負荷でパーソナルトレーニングを行うため、初心者や運動が苦手な方でも無理なく続けられます。",
    },
    {
      question: "運動が苦手でも大丈夫でしょうか？",
      answer:
        'はい、運動が苦手な方でも全く問題ありません。TRIGGERは、宮崎市で"初心者に優しいパーソナルジム"として、運動経験ゼロ・体力に自信がない方のサポートを最も得意としています。',
    },
  ],
  seitai: [
    {
      question: "整体院は資格保有者が対応ですか？",
      answer: "はい。厚生労働省から認められた、国家資格を保有する精鋭たちが丁寧に施術させていただきます。",
    },
    {
      question: "整体院は保険は使えますか？",
      answer:
        "整体院の施術は民間療法のため健康保険は使えません。保険が使えるのは、柔道整復師が行う急性のケガ（捻挫・打撲・肉離れなど）のみで、慢性的な肩こり・腰痛・姿勢改善は自費施術になります。当院では柔道整復師が対応していますが、根本改善・姿勢矯正・産後骨盤矯正に特化した施術を提供しています。",
    },
    {
      question: "整体院は都度払いで通うことができますか？",
      answer:
        "ジム会員様は整体院を都度払いでご利用いただけます。ただし、整体院のみをご利用の方は回数券制となり、単発利用（1回のみ）は行っておりません。宮崎市でパーソナルトレーニングと整体院を併用したい方には最高の施設です。",
    },
  ],
}

export default function FAQPage() {
  const [activeCategory, setActiveCategory] = useState("payment")
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const categories = [
    { id: "payment", label: "お支払いについて" },
    { id: "cancellation", label: "キャンセルポリシー" },
    { id: "gym", label: "パーソナルジムについて" },
    { id: "seitai", label: "整体院のご利用について" },
  ]

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative h-[400px] lg:h-[500px]">
          <Image src="/faq-hero-woman-workout-question.jpg" alt="よくある質問" fill className="object-cover" priority />
          <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white">
            <p className="text-sm lg:text-base mb-2 tracking-wider">よくある質問</p>
            <h1 className="text-5xl lg:text-7xl font-light italic">FAQ</h1>
          </div>
        </section>

        {/* FAQ Content */}
        <section className="py-16 lg:py-24">
          <div className="max-w-4xl mx-auto px-4">
            <h2 className="text-2xl lg:text-3xl text-center mb-3 font-light">よくあるご質問</h2>
            <p className="text-center text-gray-600 mb-12">お問い合わせの前にご確認くださいませ。</p>

            {/* Category Tabs */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => {
                    setActiveCategory(category.id)
                    setOpenIndex(null)
                  }}
                  className={`py-4 px-6 border rounded-lg transition-colors ${
                    activeCategory === category.id
                      ? "bg-[#8696a4] text-white border-[#8696a4]"
                      : "bg-white text-gray-700 border-gray-300 hover:border-[#8696a4]"
                  }`}
                >
                  {category.label}
                </button>
              ))}
            </div>

            {/* FAQ Items */}
            <div className="space-y-4">
              {faqData[activeCategory].map((item, index) => (
                <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
                  <button
                    onClick={() => setOpenIndex(openIndex === index ? null : index)}
                    className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition-colors"
                  >
                    <span className="flex items-start gap-3 flex-1">
                      <span className="text-[#c4a47c] font-semibold mt-1">Q</span>
                      <span className="font-medium">{item.question}</span>
                    </span>
                    <ChevronDown
                      className={`w-5 h-5 text-gray-400 flex-shrink-0 ml-4 transition-transform ${
                        openIndex === index ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {openIndex === index && (
                    <div className="px-6 pb-6 pt-2">
                      <div className="flex gap-3">
                        <span className="text-[#c4a47c] font-semibold">A</span>
                        <p className="text-gray-700 leading-relaxed whitespace-pre-line">{item.answer}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        <CtaBanner />
      </main>
      <Footer />
    </>
  )
}
