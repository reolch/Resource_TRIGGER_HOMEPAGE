"use client"

import type React from "react"

import Image from "next/image"
import { useState } from "react"
import { Phone, MessageCircle } from "lucide-react"
import Footer from "@/components/footer"
import Header from "@/components/header"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitMessage, setSubmitMessage] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitMessage("")

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setSubmitMessage("お問い合わせありがとうございます。後ほどご連絡いたします。")
        setFormData({ name: "", email: "", phone: "", message: "" })
      } else {
        setSubmitMessage("送信に失敗しました。もう一度お試しください。")
      }
    } catch (error) {
      setSubmitMessage("送信エラーが発生しました。")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }))
  }

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative h-[400px] lg:h-[500px]">
          <Image src="/contact-hero-gym-facility.jpg" alt="お問い合わせ" fill className="object-cover" priority />
          <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white">
            <p className="text-base lg:text-lg mb-2 tracking-wider">お問い合わせ</p>
            <h1 className="text-4xl lg:text-5xl font-light tracking-wider">CONTACT</h1>
          </div>
        </section>

        {/* Contact Methods */}
        <section className="py-16 lg:py-24 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4">
            <h2 className="text-2xl lg:text-3xl text-center mb-3 font-light">お問い合わせ方法</h2>
            <p className="text-center text-gray-600 mb-12">ご都合の良い方法でお気軽にお問い合わせください</p>

            <div className="grid md:grid-cols-3 gap-6 mb-16">
              {/* LINE */}
              <a
                href="https://line.me/R/ti/p/@841ytgtf"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#06C755] text-white p-8 rounded-lg hover:opacity-90 transition-opacity text-center group"
              >
                <MessageCircle className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">LINE</h3>
                <p className="text-sm mb-4 opacity-90">24時間受付中</p>
                <div className="inline-block border-b-2 border-white pb-1 group-hover:border-b-4 transition-all">
                  公式ライン予約
                </div>
              </a>

              {/* HOT PEPPER BEAUTY */}
              <a
                href="https://beauty.hotpepper.jp/kr/slnH000691057/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gradient-to-br from-orange-400 to-pink-500 text-white p-8 rounded-lg hover:opacity-90 transition-opacity text-center group"
              >
                <div className="w-12 h-12 mx-auto mb-4 bg-white rounded-full flex items-center justify-center text-2xl font-bold text-orange-500">
                  H
                </div>
                <h3 className="text-xl font-semibold mb-2">HOT PEPPER BEAUTY</h3>
                <p className="text-sm mb-4 opacity-90">ポイントも貯まる</p>
                <div className="inline-block border-b-2 border-white pb-1 group-hover:border-b-4 transition-all">
                  ネット予約
                </div>
              </a>

              {/* PHONE */}
              <a
                href="tel:07091071717"
                className="bg-[#8696a4] text-white p-8 rounded-lg hover:opacity-90 transition-opacity text-center group"
              >
                <Phone className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">電話</h3>
                <p className="text-sm mb-4 opacity-90">070-9107-1717</p>
                <div className="inline-block border-b-2 border-white pb-1 group-hover:border-b-4 transition-all">
                  電話予約する
                </div>
              </a>
            </div>
          </div>
        </section>

        {/* Contact Form */}
        <section className="py-16 lg:py-24">
          <div className="max-w-3xl mx-auto px-4">
            <h2 className="text-2xl lg:text-3xl text-center mb-3 font-light">メールでのお問い合わせ</h2>
            <p className="text-center text-gray-600 mb-12">下記フォームよりお問い合わせください</p>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                  お名前 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#8696a4] focus:border-transparent"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  メールアドレス <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#8696a4] focus:border-transparent"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                  電話番号
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#8696a4] focus:border-transparent"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                  お問い合わせ内容 <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#8696a4] focus:border-transparent resize-none"
                />
              </div>

              {submitMessage && (
                <div
                  className={`p-4 rounded-lg ${
                    submitMessage.includes("ありがとう") ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800"
                  }`}
                >
                  {submitMessage}
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-[#8696a4] text-white py-4 rounded-lg hover:bg-[#6d7d8a] transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium text-lg"
              >
                {isSubmitting ? "送信中..." : "送信する"}
              </button>
            </form>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
