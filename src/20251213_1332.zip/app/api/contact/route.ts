import { NextResponse } from "next/server"
import { Resend } from "resend"
import ContactEmailTemplate from "@/components/contact-email-template"

const resend = new Resend(process.env.RESEND_API_KEY)

const PRODUCTION_WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL
const TEST_WEBHOOK_URL = process.env.TEST_DISCORD_WEBHOOK_URL
const TEST_EMAIL = process.env.TEST_EMAIL || "test@gmail.com"
const TEST_CONTACT_EMAIL = process.env.TEST_CONTACT_EMAIL || "reolch@gmail.com"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, phone, message } = body

    const isTestMode = email === TEST_EMAIL
    const recipientEmail = isTestMode ? TEST_CONTACT_EMAIL : process.env.CONTACT_EMAIL || "info@trigger-gym.com"
    const webhookUrl = isTestMode ? TEST_WEBHOOK_URL : PRODUCTION_WEBHOOK_URL

    const { data, error } = await resend.emails.send({
      from: "TRIGGER <onboarding@resend.dev>",
      to: [recipientEmail],
      replyTo: email,
      subject: `【お問い合わせ】${name}様より`,
      react: ContactEmailTemplate({ name, email, phone, message }),
    })

    if (error) {
      return NextResponse.json({ error }, { status: 400 })
    }

    try {
      await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          embeds: [
            {
              title: isTestMode ? "🧪 テスト - 新しいお問い合わせ" : "📧 新しいお問い合わせ",
              color: 0xc4a47c,
              fields: [
                {
                  name: "お名前",
                  value: name,
                  inline: true,
                },
                {
                  name: "メールアドレス",
                  value: email,
                  inline: true,
                },
                {
                  name: "電話番号",
                  value: phone || "未入力",
                  inline: true,
                },
                {
                  name: "お問い合わせ内容",
                  value: message.length > 1024 ? message.substring(0, 1021) + "..." : message,
                  inline: false,
                },
              ],
              timestamp: new Date().toISOString(),
              footer: {
                text: "TRIGGER パーソナルジム＋整体院",
              },
            },
          ],
        }),
      })
    } catch (discordError) {
      console.error("Discord webhook failed:", discordError)
    }

    return NextResponse.json({ success: true, data })
  } catch (error) {
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 })
  }
}
