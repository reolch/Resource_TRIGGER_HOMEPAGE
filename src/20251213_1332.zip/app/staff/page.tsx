import Image from "next/image"
import Link from "next/link"
import Header from "@/components/header"
import CTABanner from "@/components/cta-banner"
import Footer from "@/components/footer"

const staffMembers = [
  {
    id: "yusei-yoshida",
    name: "吉田 悠成",
    image: "https://smbtrfijdjwhfcqn.public.blob.vercel-storage.com/profile-yoshida-yusei.avif",
  },
  {
    id: "ryosei-yoshinaga",
    name: "吉永 凉晴",
    image: "https://smbtrfijdjwhfcqn.public.blob.vercel-storage.com/profile-yoshinaga_ryosei.avif",
  },
]

const linkBanners = [
  {
    title: "PROGRAM",
    subtitle: "プログラム",
    href: "/program",
    image: "/personal-gym-training-session-professional.jpg",
  },
  {
    title: "FAQ",
    subtitle: "よくある質問",
    href: "/faq",
    image: "/about-studio-equipment-interior.jpg",
  },
  {
    title: "ACCESS",
    subtitle: "アクセス",
    href: "/about#access",
    image: "/about-instructor-teaching-class.jpg",
  },
]

export default function StaffPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header variant="dark" />

      {/* Hero Section */}
      <section className="relative h-[400px] lg:h-[500px] flex items-center justify-center">
        <div className="absolute inset-0">
          <Image
            src="/images/design-mode/staff-page-banner.avif"
            alt="スタッフ"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-black/40" />
        </div>

        {/* Side buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 z-20 hidden lg:flex flex-col">
          <Link
            href="/trial"
            className="bg-[#7b8d7b] text-white flex items-center justify-center transition-opacity hover:opacity-90"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
            }}
          >
            <span className="text-[13px] tracking-[0.2em]">無料体験レッスン</span>
          </Link>
          <Link
            href="/campaign"
            className="bg-[#e8c4b8] text-white flex items-center justify-center transition-opacity hover:opacity-90"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
            }}
          >
            <span className="text-[13px] tracking-[0.2em]">キャンペーン</span>
          </Link>
        </div>

        <div className="relative z-10 text-center text-white">
          <h1 className="text-4xl lg:text-5xl tracking-[0.3em] font-light italic">STAFF</h1>
        </div>
      </section>

      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-4xl mx-auto px-6 text-center mb-16">
          <h2 className="text-xl lg:text-2xl font-light tracking-wider text-[#5a7a8a]">国家資格保有者の精鋭が担当</h2>
        </div>

        {/* Staff Card */}
        <div className="max-w-3xl mx-auto px-6">
          <div className="border border-gray-200 divide-y divide-gray-200">
            {staffMembers.map((staff, index) => (
              <Link
                key={staff.id}
                href={`/staff/${staff.id}`}
                className="flex items-center gap-8 p-8 lg:p-12 hover:bg-gray-50 transition-colors"
              >
                {/* 円形写真 */}
                <div className="relative w-32 h-32 lg:w-40 lg:h-40 rounded-full overflow-hidden flex-shrink-0 border-4 border-white shadow-lg">
                  <Image
                    src={staff.image || "/placeholder.svg"}
                    alt={staff.name}
                    fill
                    className="object-cover"
                    priority={index < 2}
                  />
                </div>
                {/* 名前 */}
                <h3 className="text-lg lg:text-xl text-[#333] tracking-wider">{staff.name}</h3>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3">
        {linkBanners.map((banner, index) => (
          <Link
            key={banner.title}
            href={banner.href}
            className="relative h-48 md:h-64 flex items-center justify-center group overflow-hidden"
          >
            <Image
              src={banner.image || "/placeholder.svg"}
              alt={banner.title}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
              priority
            />
            <div className="absolute inset-0 bg-black/50 group-hover:bg-black/40 transition-colors" />
            <div className="relative z-10 text-center text-white">
              <p className="text-xs tracking-[0.2em] mb-2">{banner.subtitle}</p>
              <h3 className="text-2xl lg:text-3xl tracking-[0.15em] font-light">{banner.title}</h3>
            </div>
          </Link>
        ))}
      </section>

      <CTABanner />
      <Footer />
    </main>
  )
}
