import Header from "@/components/header"
import Footer from "@/components/footer"
import Image from "next/image"
import Link from "next/link"

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header variant="dark" />

      {/* Hero Banner */}
      <section className="relative h-[400px] lg:h-[500px] overflow-hidden">
        <Image src="/about-hero-yoga-women-studio.jpg" alt="TRIGGER スタジオ" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center">
          <p className="text-[13px] tracking-[0.2em] mb-3">TRIGGERについて</p>
          <h1 className="text-4xl md:text-5xl tracking-[0.15em] font-light">ABOUT</h1>
        </div>
      </section>

      {/* Section 1 - Introduction */}
      <section className="py-20 md:py-28 px-6">
        <div className="max-w-[800px] mx-auto text-center">
          <h2 className="text-[#c4a47c] text-xl md:text-2xl leading-relaxed mb-8 tracking-wide">
            TRIGGERは、
            <br />
            宮崎市で「結果が出るパーソナルトレーニング」にこだわるパーソナルジムです。
          </h2>
          <p className="text-[#555] text-[14px] md:text-[15px] leading-[2] tracking-wide">
            宮崎市で唯一パーソナルジムに整体院が併設。
            在籍するトレーナーは、知識・技術の向上を常に追求し、体づくりのプロとしてお客様の目標を最短で達成することを重視しています。
            「痩せたい」「引き締めたい」「姿勢を良くしたい」「体力を付けたい」など、
            お客様一人ひとりの目的に合わせた完全オーダーメイドのトレーニングを提供。
            見た目の変化だけではなく、毎日を前向きに過ごせるよう内面（メンタル面）からのサポートも行っています。
            トレーナーは国家資格保有者しか採用しておらず、宮崎トップレベルの精鋭たちが集うパーソナルジムとなります。
            宮崎市で「本気で変わりたい」「続けられるパーソナルジムを探している」方は、TRIGGERにお任せください。
            初心者でも安心して始められる環境と、確実に効果が実感できる指導をご提供します。
          </p>
        </div>
      </section>

      {/* Section 1 - Image */}
      <section className="px-6 md:px-12 lg:px-20">
        <div className="max-w-[900px] mx-auto">
          <div className="relative aspect-[16/10] overflow-hidden">
            <Image
              src="/about-yoga-woman-stretching-studio.jpg"
              alt="ヨガポーズ"
              fill
              className="object-cover"
              priority
            />
          </div>
        </div>
      </section>

      {/* Section 2 - Equipment */}
      <section className="py-20 md:py-28 px-6">
        <div className="max-w-[800px] mx-auto text-center">
          <h2 className="text-[#c4a47c] text-xl md:text-2xl leading-relaxed mb-8 tracking-wide">
            業界最新のマシンや設備が完備
          </h2>
          <p className="text-[#555] text-[14px] md:text-[15px] leading-[2] tracking-wide">
            効果的にトレーニングを行うため、当スタジオでは業界最先端のマシンや設備を完備しています。ピラティス専用のリフォーマーやキャデラック、チェアといったマシンを活用し、マットだけでは鍛えにくい筋肉にまでアプローチすることが可能です。また、広々としたスタジオ空間は、開放感がありながらも落ち着いた雰囲気で、レッスンに集中できる環境を整えています。
          </p>
        </div>
      </section>

      {/* Section 2 - Image Grid */}
      <section className="px-6 md:px-12 lg:px-20 pb-20 md:pb-28">
        <div className="max-w-[900px] mx-auto">
          <div className="grid grid-cols-2 gap-4">
            <div className="relative aspect-[4/3] overflow-hidden">
              <Image src="/about-pilates-reformer-woman.jpg" alt="ピラティスマシン" fill className="object-cover" />
            </div>
            <div className="relative aspect-[4/3] overflow-hidden">
              <Image src="/about-studio-equipment-interior.jpg" alt="スタジオ設備" fill className="object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Section 3 - Instructors */}
      <section className="py-20 md:py-28 px-6 bg-[#f8f8f6]">
        <div className="max-w-[800px] mx-auto text-center">
          <h2 className="text-[#c4a47c] text-xl md:text-2xl leading-relaxed mb-8 tracking-wide">
            資格を持つプロフェッショナルが
            <br />
            丁寧に指導いたします
          </h2>
          <p className="text-[#555] text-[14px] md:text-[15px] leading-[2] tracking-wide">
            当スタジオのインストラクターは全員、国内外で認められた資格を持つプロフェッショナルです。それぞれが豊富な経験と専門知識を持ち、お客様一人ひとりの体型や目標に合わせた最適なアドバイスを行います。初心者の方でも安心して取り組めるよう、基本的な動きからゆっくりと丁寧にお教えします。
          </p>
        </div>
      </section>

      {/* Section 3 - Image */}
      <section className="px-6 md:px-12 lg:px-20 bg-[#f8f8f6] pb-20 md:pb-28">
        <div className="max-w-[900px] mx-auto">
          <div className="relative aspect-[16/10] overflow-hidden">
            <Image
              src="/about-instructor-teaching-class.jpg"
              alt="インストラクター指導"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>

      {/* Access Section */}
      <section className="py-20 md:py-28 px-6">
        <div className="max-w-[930px] mx-auto">
          <hgroup className="text-center mb-12">
            <p className="text-[#c4a47c] text-[13px] tracking-[0.15em] mb-2">アクセス</p>
            <h2 className="text-2xl md:text-3xl tracking-[0.1em] text-[#333] font-light">ACCESS</h2>
          </hgroup>

          <div className="grid md:grid-cols-2 gap-10 md:gap-16">
            {/* Map */}
            <div className="relative aspect-square md:aspect-auto md:h-[350px] bg-[#e5e5e5]">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3240.828030957394!2d139.76493807654796!3d35.68123587259089!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x60188bfbd89f700b%3A0x277c49ba34ed38!2z5p2x5Lqs6aeF!5e0!3m2!1sja!2sjp!4v1699000000000!5m2!1sja!2sjp"
                className="w-full h-full border-0"
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>

            {/* Info */}
            <div className="flex flex-col justify-center">
              <h3 className="text-xl md:text-2xl tracking-[0.2em] text-[#333] font-light mb-6">TRIGGER</h3>
              <dl className="space-y-4 text-[14px] text-[#555]">
                <div className="flex">
                  <dt className="w-24 text-[#999]">住所</dt>
                  <dd>
                    〒880-0055
                    <br />
                    宮崎県宮崎市南花ケ島町１３２−１
                    <br />
                    川村ビル １F
                  </dd>
                </div>
                <div className="flex">
                  <dt className="w-24 text-[#999]">電話番号</dt>
                  <dd>
                    <a href="tel:070-9107-1717">TEL:070-9107-1717</a>
                  </dd>
                </div>
                <div className="flex">
                  <dt className="w-24 text-[#999]">営業時間</dt>
                  <dd>
                    平日 10:00〜22:00
                    <br />
                    土日祝 9:00〜20:00
                  </dd>
                </div>
                <div className="flex">
                  <dt className="w-24 text-[#999]">定休日</dt>
                  <dd>毎週火曜日</dd>
                </div>
              </dl>
              <Link
                href="https://maps.google.com"
                target="_blank"
                className="inline-flex items-center gap-2 mt-8 text-[13px] text-[#333] border-b border-[#333] pb-1 hover:text-[#c4a47c] hover:border-[#c4a47c] transition-colors self-start"
              >
                Google Mapで見る
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
