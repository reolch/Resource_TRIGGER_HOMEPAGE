import Header from "@/components/header"
import Footer from "@/components/footer"
import CtaBanner from "@/components/cta-banner"
import Image from "next/image"
import Link from "next/link"
import { Clock } from "lucide-react"

const newsItems = [
  {
    slug: "night_program",
    title: "夜のリラックスピラティス｜1日の疲れを癒すナイトプログラム登場！",
    date: "2025.03.07",
    category: "レッスン",
    categorySlug: "lesson",
    image: "/news-night-pilates-relaxing.jpg",
  },
  {
    slug: "instructor",
    title: "インストラクター紹介｜TRIGGERのスペシャリスト",
    date: "2025.02.26",
    category: "イベント",
    categorySlug: "event",
    image: "/news-instructor-introduction.jpg",
  },
  {
    slug: "product",
    title: "TRIGGERオリジナルグッズ販売スタート！",
    date: "2025.02.02",
    category: "キャンペーン",
    categorySlug: "campaign",
    image: "/news-original-goods-products.jpg",
  },
  {
    slug: "difference",
    title: "ヨガとピラティスの違いは？あなたに合うのはどっち？",
    date: "2025.01.12",
    category: "イベント",
    categorySlug: "event",
    image: "/news-yoga-pilates-difference.jpg",
  },
  {
    slug: "at-home",
    title: "オンラインレッスン｜おうちでピラティス！",
    date: "2024.11.22",
    category: "レッスン",
    categorySlug: "lesson",
    image: "/news-online-lesson-home.jpg",
  },
  {
    slug: "pair",
    title: "期間限定ペア割キャンペーン！お友達や家族と一緒にお得に参加",
    date: "2024.11.16",
    category: "キャンペーン",
    categorySlug: "campaign",
    image: "/news-pair-campaign-friends.jpg",
  },
]

export default function NewsPage() {
  return (
    <main className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-[400px] lg:h-[500px]">
        <Image src="/news-hero-yoga-stretching.jpg" alt="お知らせ" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-black/30" />
        <Header variant="light" />

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 z-20 hidden md:flex flex-col">
          <Link
            href="/trial"
            className="flex items-center justify-center text-white text-sm tracking-wider"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
              backgroundColor: "#7b8d7b",
            }}
          >
            無料体験レッスン
          </Link>
          <Link
            href="/reserve"
            className="flex items-center justify-center text-white text-sm tracking-wider"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
              backgroundColor: "#e8a598",
            }}
          >
            レッスン予約
          </Link>
        </div>

        {/* Title */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center">
          <p className="text-sm tracking-[0.3em] mb-4">お知らせ</p>
          <h1 className="text-4xl md:text-5xl font-light tracking-[0.2em]">NEWS</h1>
        </div>
      </section>

      {/* News List Section */}
      <section className="py-20 md:py-28">
        <div className="max-w-[900px] mx-auto px-4">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-2xl md:text-3xl text-[#3d4a4f] mb-6">新着のお知らせ</h2>
            <p className="text-[#666] text-sm leading-relaxed">
              新しいイベントやキャンペーン、休講・振替情報など、さまざまなお知らせをまとめてご案内。
              <br className="hidden md:block" />
              ぜひ定期的にチェックしてください。
            </p>
          </div>

          {/* News Items */}
          <div className="space-y-0">
            {newsItems.map((item, index) => (
              <Link
                key={index}
                href={`/news/${item.slug}`}
                className="flex flex-col md:flex-row gap-6 py-8 border-t border-[#e5e5e5] group hover:bg-[#fafafa] transition-colors"
              >
                {/* Image */}
                <div className="relative w-full md:w-[220px] h-[180px] md:h-[150px] flex-shrink-0 overflow-hidden">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>

                {/* Content */}
                <div className="flex flex-col justify-center">
                  <div className="flex items-center gap-4 mb-3">
                    <span className="flex items-center gap-1 text-[#999] text-xs">
                      <Clock className="w-3 h-3" />
                      {item.date}
                    </span>
                    <span className="text-xs text-[#999]">{item.category}</span>
                  </div>
                  <h3 className="text-[#333] text-base md:text-lg leading-relaxed group-hover:text-[#c4a47c] transition-colors">
                    {item.title}
                  </h3>
                </div>
              </Link>
            ))}
            {/* Last border */}
            <div className="border-t border-[#e5e5e5]" />
          </div>
        </div>
      </section>

      <CtaBanner />
      <Footer />
    </main>
  )
}
