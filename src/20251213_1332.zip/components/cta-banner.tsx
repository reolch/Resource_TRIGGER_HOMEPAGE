import Link from "next/link"

export function CtaBanner() {
  return (
    <section className="bg-[#3d4a4f] py-6">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8">
          <p className="text-white/90 text-[13px] lg:text-sm text-center">
            体験レッスンを予約してみる
          </p>
          <Link
            href=""
            className="inline-block bg-[#c4a47c] text-white text-[12px] tracking-wider px-8 py-3 hover:bg-[#b08f6a] transition-colors"
          >
            LINEから予約する
          </Link>

          <a
            href="tel:070-9107-1717"
            className="inline-block bg-[#c4a47c] text-white text-[12px] tracking-wider px-8 py-3 hover:bg-[#b08f6a] transition-colors"
          >
            電話から予約する
          </a>
        </div>
      </div>
    </section>
  )
}

export const CTABanner = CtaBanner
export default CtaBanner
