interface ContactEmailTemplateProps {
  name: string
  email: string
  phone?: string
  message: string
}

export default function ContactEmailTemplate({ name, email, phone, message }: ContactEmailTemplateProps) {
  return (
    <div style={{ fontFamily: "sans-serif", maxWidth: "600px", margin: "0 auto" }}>
      <h2 style={{ color: "#8696a4", borderBottom: "2px solid #c4a47c", paddingBottom: "10px" }}>新しいお問い合わせ</h2>
      <div style={{ marginTop: "20px" }}>
        <p>
          <strong>お名前:</strong> {name}
        </p>
        <p>
          <strong>メールアドレス:</strong> {email}
        </p>
        {phone && (
          <p>
            <strong>電話番号:</strong> {phone}
          </p>
        )}
        <p>
          <strong>お問い合わせ内容:</strong>
        </p>
        <div
          style={{
            backgroundColor: "#f5f5f5",
            padding: "15px",
            borderRadius: "5px",
            whiteSpace: "pre-wrap",
          }}
        >
          {message}
        </div>
      </div>
    </div>
  )
}
