import Link from "next/link"

export default function AccessSection() {
  return (
    <section className="py-20 md:py-28 px-6 bg-[#f8f8f6]">
      <div className="max-w-[930px] mx-auto">
        <hgroup className="text-center mb-12">
          <p className="text-[#c4a47c] text-[13px] tracking-[0.15em] mb-2">アクセス</p>
          <h2 className="text-2xl md:text-3xl tracking-[0.1em] text-[#333] font-light">ACCESS</h2>
        </hgroup>

        <div className="grid md:grid-cols-2 gap-10 md:gap-16">
          {/* Map */}
          <div className="relative aspect-square md:aspect-auto md:h-[350px] bg-[#e5e5e5]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3392.7516752767644!2d131.4174687!3d31.7743924!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x353fb26c9c9d3b5d%3A0x1234567890abcdef!2sTRIGGER!5e0!3m2!1sja!2sjp!4v1699000000000!5m2!1sja!2sjp"
              className="w-full h-full border-0"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>

          {/* Info */}
          <div className="flex flex-col justify-center">
            <h3 className="text-xl md:text-2xl tracking-[0.2em] text-[#333] font-light mb-6">TRIGGER</h3>
            <dl className="space-y-4 text-[14px] text-[#555]">
              <div className="flex">
                <dt className="w-24 text-[#999]">住所</dt>
                <dd>
                  〒880-0055
                  <br />
                  宮崎県宮崎市南花ケ島町１３２−１
                  <br />
                  川村ビル １F
                </dd>
              </div>
              <div className="flex">
                <dt className="w-24 text-[#999]">電話番号</dt>
                <dd>
                  <a href="tel:070-9107-1717" className="hover:text-[#c4a47c] transition-colors">
                    TEL:070-9107-1717
                  </a>
                </dd>
              </div>
              <div className="flex">
                <dt className="w-24 text-[#999]">営業時間</dt>
                <dd>
                  平日 10:00〜22:00
                  <br />
                  土日祝 9:00〜20:00
                </dd>
              </div>
              <div className="flex">
                <dt className="w-24 text-[#999]">定休日</dt>
                <dd>毎週火曜日</dd>
              </div>
            </dl>
            <Link
              href="/access"
              className="inline-flex items-center gap-2 mt-8 text-[13px] text-[#333] border-b border-[#333] pb-1 hover:text-[#c4a47c] hover:border-[#c4a47c] transition-colors self-start"
            >
              詳しく見る
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
