"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { blogPosts } from "@/lib/blog-posts"

const categories = ["すべて", "ヨガ", "ピラティス", "健康", "ライフスタイル"]

const BlogSection = () => {
  const [activeCategory, setActiveCategory] = useState("すべて")

  const filteredPosts =
    activeCategory === "すべて"
      ? blogPosts.slice(0, 3)
      : blogPosts.filter((post) => post.category === activeCategory).slice(0, 3)

  return (
    <section className="py-20 bg-[#f8f8f6]">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-sm text-[#c4a47c] tracking-[0.2em] mb-2">ブログ</p>
          <h2 className="text-4xl font-bold text-gray-900 mb-8">BLOG</h2>
        </div>

        <div className="flex justify-center gap-4 mb-12 flex-wrap">
          {categories.map((category) => (
            <button
              key={category}
              className={`px-8 py-3 rounded-full text-sm font-medium transition-all ${
                activeCategory === category ? "bg-black text-white" : "bg-white text-gray-700 hover:bg-gray-100"
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="space-y-6">
          {filteredPosts.map((post) => (
            <Link
              key={post.id}
              href={`/blog/${post.slug}`}
              className="flex gap-6 group hover:opacity-80 transition-opacity"
            >
              <div className="relative w-[280px] h-[180px] flex-shrink-0 overflow-hidden hidden md:block">
                <Image
                  src={post.image || "/placeholder.svg"}
                  alt={post.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="flex-1 flex flex-col justify-center">
                <div className="flex items-center gap-4 mb-3">
                  <time className="text-sm text-gray-500">{post.date}</time>
                  <span className="px-3 py-1 bg-[#c4a47c] text-white text-xs rounded">{post.category}</span>
                </div>
                <h3 className="text-base font-medium text-gray-900 group-hover:text-[#c4a47c] transition-colors md:text-lg">
                  {post.title}
                </h3>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link
            href="/blog"
            className="inline-block px-12 py-4 bg-black text-white text-sm font-medium hover:bg-gray-800 transition-colors"
          >
            ブログ一覧
          </Link>
        </div>
      </div>
    </section>
  )
}

export default BlogSection
