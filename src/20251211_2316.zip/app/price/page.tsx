import Header from "@/components/header"
import Footer from "@/components/footer"
import CtaBanner from "@/components/cta-banner"
import Image from "next/image"

export default function PricePage() {
  return (
    <main className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Section */}
      <section className="relative h-[400px] overflow-hidden">
        <Image src="/price-hero-yoga-mat-woman.jpg" alt="料金表" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-black/30" />
        <div className="relative z-10 flex h-full flex-col items-center justify-center text-white">
          <p className="mb-2 text-sm tracking-widest">料金表</p>
          <h1 className="text-4xl font-light tracking-[0.3em] md:text-5xl">PRICE</h1>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 z-20 hidden -translate-y-1/2 flex-col lg:flex">
          <a
            href="#"
            className="flex items-center justify-center bg-[#7b8d7b] text-white transition-opacity hover:opacity-80"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
            }}
          >
            <span className="text-sm tracking-widest">無料体験レッスン</span>
          </a>
          <a
            href="#"
            className="flex items-center justify-center bg-[#e8a598] text-white transition-opacity hover:opacity-80"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
            }}
          >
            <span className="text-sm tracking-widest">レッスン予約</span>
          </a>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-20">
        <div className="mx-auto max-w-[930px] px-4 text-center">
          <h2 className="mb-16 text-xl leading-relaxed text-[#666] md:text-2xl">
            あなたのライフスタイルに合わせて
            <br />
            様々なプログラムをご用意
          </h2>

          {/* Trial Lesson Card */}
          <div className="mb-16 overflow-hidden border border-gray-200">
            <div className="relative h-[200px] overflow-hidden">
              <Image src="/price-trial-lesson-yoga.jpg" alt="体験レッスン" fill className="object-cover" />
              <div className="absolute inset-0 bg-black/40" />
              <div className="relative z-10 flex h-full items-center justify-center">
                <h3 className="text-2xl font-light tracking-widest text-white">体験レッスン</h3>
              </div>
            </div>
            <div className="bg-white p-8">
              <p className="mb-2 text-[#333]">まずは体験レッスンでスタジオの雰囲気を気軽にチェックしてみてください。</p>
              <p className="mb-6 text-[#333]">
                体験レッスン当日にご入会いただくと、入会金が無料になるのでとってもお得です。
              </p>
              <div className="flex items-center justify-between border-t border-gray-200 pt-6">
                <span className="text-[#333]">初回体験</span>
                <span className="text-[#333]">
                  <span className="mr-2 text-gray-400 line-through">3,000円</span>→ 0円
                </span>
              </div>
            </div>
          </div>

          {/* Hot Yoga */}
          <PriceTable
            title="ホットヨガ"
            bgColor="#7b8d7b"
            items={[
              { name: "4回チケット", price: "12,000円（3,000円／回）" },
              { name: "6回チケット", price: "16,200円（2,700円／回）" },
              { name: "10回チケット", price: "25,000円（2,500円／回）" },
              { name: "追加チケット", price: "4,000円" },
            ]}
          />

          {/* Morning Yoga */}
          <PriceTable
            title="モーニングヨガ"
            bgColor="#7b8d7b"
            items={[
              { name: "4回チケット", price: "8,000円（2,000円／回）" },
              { name: "6回チケット", price: "10,800円（1,800円／回）" },
              { name: "10回チケット", price: "17,000円（1,700円／回）" },
              { name: "追加チケット", price: "2,500円" },
            ]}
          />

          {/* Note */}
          <p className="mb-16 text-left text-sm leading-relaxed text-[#666]">
            ＊チケットの有効期限は毎月1日（入会月においては入会日）から末日までになります。追加チケットの有効期限は購入日から当月末日までとします。期間経過後、翌月にチケットを持ち越すことはできません。
          </p>

          {/* Mat Pilates */}
          <PriceTable
            title="マットピラティス"
            bgColor="#a08060"
            items={[
              { name: "4回チケット", price: "10,000円（2,500円／回）" },
              { name: "6回チケット", price: "13,200円（2,200円／回）" },
              { name: "10回チケット", price: "20,000円（2,000円／回）" },
              { name: "追加チケット", price: "3,000円" },
            ]}
          />

          {/* Machine Pilates */}
          <PriceTable
            title="マシンピラティス"
            bgColor="#a08060"
            items={[
              { name: "4回チケット", price: "14,000円（3,500円／回）" },
              { name: "6回チケット", price: "19,200円（3,200円／回）" },
              { name: "10回チケット", price: "30,000円（3,000円／回）" },
              { name: "追加チケット", price: "4,000円" },
            ]}
          />

          {/* Personal Lesson */}
          <div className="mb-16">
            <div className="bg-[#3d4a4f] py-4">
              <h3 className="text-lg tracking-widest text-white">パーソナルレッスン</h3>
            </div>
            <p className="border-x border-gray-200 bg-gray-50 px-4 py-4 text-sm text-[#666]">
              グループレッスンにプラスしてパーソナルレッスンを受けられるプランです。より集中して取り組みたい方におすすめです。
            </p>
            <div className="border border-t-0 border-gray-200">
              {[
                { name: "4回チケット", price: "26,000円（6,500円／回）" },
                { name: "6回チケット", price: "36,000円（6,000円／回）" },
                { name: "10回チケット", price: "55,000円（5,500円／回）" },
                { name: "追加チケット", price: "7,000円" },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between border-b border-gray-200 px-6 py-4 last:border-b-0"
                >
                  <span className="text-[#333]">{item.name}</span>
                  <span className="text-[#333]">{item.price}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Other Services */}
          <div className="mb-16">
            <div className="bg-[#3d4a4f] py-4">
              <h3 className="text-lg tracking-widest text-white">その他サービス</h3>
            </div>
            <div className="border border-t-0 border-gray-200">
              {[
                { name: "レンタルマット1回", price: "800円" },
                { name: "レンタルマット1カ月", price: "5,000円" },
                { name: "レンタルウェア（上下セット）", price: "1,000円" },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between border-b border-gray-200 px-6 py-4 last:border-b-0"
                >
                  <span className="text-[#333]">{item.name}</span>
                  <span className="text-[#333]">{item.price}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <CtaBanner />
      <Footer />
    </main>
  )
}

function PriceTable({
  title,
  bgColor,
  items,
}: {
  title: string
  bgColor: string
  items: { name: string; price: string }[]
}) {
  return (
    <div className="mb-10">
      <div style={{ backgroundColor: bgColor }} className="py-4">
        <h3 className="text-lg tracking-widest text-white">{title}</h3>
      </div>
      <div className="border border-t-0 border-gray-200">
        {items.map((item, index) => (
          <div
            key={index}
            className="flex items-center justify-between border-b border-gray-200 px-6 py-4 last:border-b-0"
          >
            <span className="text-[#333]">{item.name}</span>
            <span className="text-[#333]">{item.price}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
