import Header from "@/components/header"
import Footer from "@/components/footer"
import CtaBanner from "@/components/cta-banner"
import { ChevronRight } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function YogaPage() {
  const subPrograms = [
    { id: "hot-yoga", name: "ホットヨガ" },
    { id: "morning-yoga", name: "モーニングヨガ" },
    { id: "group-lesson", name: "グループレッスン" },
  ]

  return (
    <main className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Banner */}
      <section className="relative h-[50vh] min-h-[400px]">
        <Image src="/yoga-hero-woman-stretching-studio.jpg" alt="YOGA" fill className="object-cover" />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center">
          <p className="text-sm tracking-[0.3em] mb-2">ヨガ</p>
          <h1 className="text-4xl md:text-5xl font-light tracking-[0.2em]">YOGA</h1>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden lg:flex flex-col z-10">
          <Link
            href="/trial"
            className="flex items-center justify-center bg-[#7b8d7b] text-white text-sm tracking-wider hover:opacity-90 transition-opacity"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            無料体験レッスン
          </Link>
          <Link
            href="/reserve"
            className="flex items-center justify-center bg-[#e8b4a8] text-white text-sm tracking-wider hover:opacity-90 transition-opacity"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            レッスン予約
          </Link>
        </div>
      </section>

      {/* Breadcrumb */}
      <div className="bg-white py-4">
        <div className="max-w-[1200px] mx-auto px-6">
          <nav className="flex items-center gap-2 text-sm text-gray-500">
            <Link href="/" className="hover:text-gray-800">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
                />
              </svg>
            </Link>
            <ChevronRight className="w-3 h-3" />
            <Link href="/program" className="hover:text-gray-800">
              プログラム
            </Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-[#7b8d7b]">YOGA</span>
          </nav>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="bg-[#7b8d7b]">
        <div className="max-w-[1200px] mx-auto">
          <nav className="flex justify-center">
            {subPrograms.map((program, index) => (
              <a
                key={program.id}
                href={`#${program.id}`}
                className="text-white text-sm py-4 px-8 hover:bg-[#6a7c6a] transition-colors border-r border-[#6a7c6a] last:border-r-0"
              >
                {program.name}
              </a>
            ))}
          </nav>
        </div>
      </div>

      {/* Introduction */}
      <section className="py-20">
        <div className="max-w-[800px] mx-auto px-6 text-center">
          <p className="text-gray-600 leading-[2] text-[15px]">
            ヨガは、古代インド発祥の心身を整えるためのメソッドであり、呼吸・瞑想・ポーズ（アーサナ）を組み合わせることで、心と体のバランスを整えることを目的としています。単なる運動ではなく、深い呼吸を意識しながらゆっくりと体を動かすことで、リラックス効果を高め、ストレスを軽減することができます。柔軟性の向上や筋力強化にも効果的です。
          </p>
        </div>
      </section>

      {/* Hot Yoga Section */}
      <section id="hot-yoga" className="py-16">
        <div className="max-w-[800px] mx-auto px-6">
          <div className="text-center mb-12">
            <p className="text-[#c4a47c] text-sm tracking-wider mb-2">ホットヨガ</p>
            <h2 className="text-2xl md:text-3xl font-light text-gray-800 relative inline-block pb-4">
              発汗を促し体をほぐす
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-[1px] bg-[#c4a47c]"></span>
            </h2>
          </div>
          <p className="text-gray-600 leading-[2] text-[15px] mb-10">
            ホットヨガは、温度35〜40℃、湿度50〜60％の環境で行うヨガのスタイルで、発汗を促しながら体をしっかりと伸ばし、筋肉をほぐしていくことが特徴です。温かい環境の中で行うことで、筋肉が柔らかくなり、関節の可動域が広がるため、初心者の方でも無理なくポーズをとることができます。また、大量に汗をかくことで老廃物の排出を促し、デトックス効果が期待できます。
          </p>
          <div className="mb-10">
            <Image
              src="/yoga-hot-yoga-woman-stretching.jpg"
              alt="ホットヨガ"
              width={800}
              height={500}
              className="w-full h-auto"
            />
          </div>
          <p className="text-gray-600 leading-[2] text-[15px] mb-10">
            当スタジオのホットヨガクラスでは、初心者向けのリラックス系から、少し運動量の多いダイナミックなポーズを取り入れたクラスまで、さまざまなプログラムをご用意しています。特に冷え性やむくみに悩んでいる方、運動不足を解消したい方、ストレスを発散したい方におすすめです。温かい環境の中で深い呼吸をしながら心地よく汗をかき、心も体もリフレッシュしましょう。
          </p>
          <div>
            <Image
              src="/yoga-hot-yoga-class-women.jpg"
              alt="ホットヨガクラス"
              width={800}
              height={500}
              className="w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* Morning Yoga Section */}
      <section id="morning-yoga" className="py-16">
        <div className="max-w-[800px] mx-auto px-6">
          <div className="text-center mb-12">
            <p className="text-[#c4a47c] text-sm tracking-wider mb-2">モーニングヨガ</p>
            <h2 className="text-2xl md:text-3xl font-light text-gray-800 relative inline-block pb-4">
              自律神経を整え一日中スッキリ
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-[1px] bg-[#c4a47c]"></span>
            </h2>
          </div>
          <p className="text-gray-600 leading-[2] text-[15px] mb-10">
            モーニングヨガは、朝の時間帯に行うヨガのプログラムで、1日のスタートを穏やかに迎えるために最適です。朝は体が硬くなりがちですが、ゆっくりとストレッチをしながら筋肉を目覚めさせることで、スムーズに活動できるようになります。また、深い呼吸とともに体を動かすことで、自律神経が整い、頭がスッキリとし、集中力が高まる効果も期待できます。
          </p>
          <div className="mb-10">
            <Image
              src="/yoga-morning-yoga-sunrise.jpg"
              alt="モーニングヨガ"
              width={800}
              height={500}
              className="w-full h-auto"
            />
          </div>
          <p className="text-gray-600 leading-[2] text-[15px]">
            当スタジオのモーニングヨガでは、ゆったりとした動きの中で全身をほぐしながら、徐々にエネルギーを高めていく構成になっています。特に、朝に弱い方や、日中のパフォーマンスを向上させたい方におすすめです。さらに、朝ヨガを習慣化することで、代謝がアップし、1日を通して脂肪燃焼しやすい体を作ることができます。
          </p>
        </div>
      </section>

      {/* Group Lesson Section */}
      <section id="group-lesson" className="py-16">
        <div className="max-w-[800px] mx-auto px-6">
          <div className="text-center mb-12">
            <p className="text-[#c4a47c] text-sm tracking-wider mb-2">グループレッスン</p>
            <h2 className="text-2xl md:text-3xl font-light text-gray-800 relative inline-block pb-4">
              仲間と一緒に楽しくエクササイズ
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-[1px] bg-[#c4a47c]"></span>
            </h2>
          </div>
          <p className="text-gray-600 leading-[2] text-[15px] mb-10">
            ヨガを一人で行うのが不安な方や、仲間と一緒に楽しく取り組みたい方には、グループレッスンがおすすめです。当スタジオのグループレッスンでは、経験豊富なインストラクターが丁寧に指導しながら、クラスの雰囲気に合わせてレッスンを進めていきます。集団のエネルギーを感じながらモチベーションを高めることができるのが、グループレッスンの魅力です。
          </p>
          <div className="mb-10">
            <Image
              src="/yoga-group-lesson-women.jpg"
              alt="グループレッスン"
              width={800}
              height={500}
              className="w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* Price Info */}
      <section className="py-16 bg-[#f9f9f7]">
        <div className="max-w-[800px] mx-auto px-6 text-center">
          <p className="text-gray-600 leading-[2] text-[15px] mb-8">
            レッスンは、わかりやすいチケット制です。ピラティスやヨガのグループレッスン・パーソナルレッスンに通い放題であなたの好きな時間にいつでもご予約いただけます。
          </p>
          <Link
            href="/price"
            className="inline-block bg-gray-900 text-white px-12 py-4 text-sm tracking-wider hover:bg-gray-800 transition-colors"
          >
            料金表はこちら
          </Link>
        </div>
      </section>

      <CtaBanner />
      <Footer />
    </main>
  )
}
