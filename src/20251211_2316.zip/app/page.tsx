"use client"

import Preloader from "@/components/preloader"
import Header from "@/components/header"
import HeroSection from "@/components/hero-section"
import CategoryCards from "@/components/category-cards"
import BannerCards from "@/components/banner-cards"
import ConceptSection from "@/components/concept-section"
import StudioSection from "@/components/studio-section"
import StaffIntroSection from "@/components/staff-intro-section"
import PrideSection from "@/components/pride-section"
import ProgramGrid from "@/components/program-grid"
import NewsSection from "@/components/news-section"
import ExperienceSection from "@/components/experience-section"
import CTABanner from "@/components/cta-banner"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <>
      {/* Preloaderを表示 */}
      <Preloader />
      <main className="min-h-screen bg-background">
        <Header />
        <HeroSection />
        <CategoryCards />
        <BannerCards />
        <ConceptSection />
        <StudioSection />
        <StaffIntroSection />
        <PrideSection />
        <ProgramGrid />
        <NewsSection />
        <ExperienceSection />
        <CTABanner />
        <Footer />
      </main>
    </>
  )
}
