import Header from "@/components/header"
import Footer from "@/components/footer"
import CtaBanner from "@/components/cta-banner"
import Image from "next/image"
import Link from "next/link"
import { Clock, Users, Gift } from "lucide-react"

export default function CampaignPage() {
  const benefits = [
    {
      icon: Gift,
      title: "入会金無料",
      description: "通常11,000円の入会金が今だけ無料！お得にスタートできるチャンスです。",
    },
    {
      icon: Users,
      title: "ペア割引",
      description: "お友達やご家族と一緒に入会すると、月会費が初月50%OFF！",
    },
    {
      icon: Clock,
      title: "体験レッスン無料",
      description: "通常3,000円の体験レッスンも無料で受けられます。",
    },
  ]

  const plans = [
    {
      name: "ライトプラン",
      regular: "8,800",
      campaign: "4,400",
      description: "月4回までのレッスン",
    },
    {
      name: "スタンダードプラン",
      regular: "12,800",
      campaign: "6,400",
      description: "月8回までのレッスン",
    },
    {
      name: "プレミアムプラン",
      regular: "16,800",
      campaign: "8,400",
      description: "レッスン受け放題",
    },
  ]

  return (
    <>
      <Header variant="light" />

      {/* Hero Section */}
      <section className="relative h-[70vh] min-h-[500px] flex items-center justify-center">
        <Image
          src="/women-yoga-class-celebration-happy-studio.jpg"
          alt="春の入会キャンペーン"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-[#c4a47c]/40" />
        <div className="relative z-10 text-center text-white px-4">
          <p className="text-sm md:text-base tracking-[0.3em] mb-4 bg-white/20 backdrop-blur-sm inline-block px-6 py-2 rounded-full">
            期間限定
          </p>
          <h1 className="text-3xl md:text-5xl font-medium tracking-wider mb-4 mt-6">春の入会キャンペーン</h1>
          <p className="text-lg md:text-xl tracking-wider mb-8 opacity-90">入会金無料 + 初月月会費50%OFF</p>
          <p className="text-sm tracking-wider mb-8 bg-black/30 inline-block px-6 py-2 rounded-full">
            2025年4月1日〜4月30日
          </p>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-20 md:py-28">
        <div className="max-w-[800px] mx-auto px-6 text-center">
          <p className="text-[#c4a47c] text-sm tracking-[0.2em] mb-4">SPRING CAMPAIGN</p>
          <h2 className="text-2xl md:text-3xl text-[#3d4a4f] tracking-wider mb-8">新しい自分に出会う、春。</h2>
          <p className="text-[15px] leading-[2.2] text-[#333]">
            春は新しいことを始めるのにぴったりの季節。
            <br />
            TRIGGERでは、あなたの新しいスタートを応援する特別キャンペーンを実施中です。
            <br />
            入会金無料に加え、初月の月会費が50%OFFになるお得なこの機会をお見逃しなく。
          </p>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 md:py-28 bg-[#f8f8f6]">
        <div className="max-w-[930px] mx-auto px-6">
          <h2 className="text-2xl md:text-3xl text-center text-[#3d4a4f] tracking-wider mb-16">キャンペーン特典</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="bg-white p-8 text-center">
                <div className="w-20 h-20 rounded-full bg-[#c4a47c]/10 flex items-center justify-center mx-auto mb-6">
                  <benefit.icon className="w-10 h-10 text-[#c4a47c]" />
                </div>
                <h3 className="text-lg font-medium text-[#333] mb-4">{benefit.title}</h3>
                <p className="text-[14px] leading-[1.9] text-[#666]">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 md:py-28">
        <div className="max-w-[930px] mx-auto px-6">
          <h2 className="text-2xl md:text-3xl text-center text-[#3d4a4f] tracking-wider mb-6">キャンペーン料金</h2>
          <p className="text-center text-[#666] text-sm mb-16">初月の月会費が50%OFF！</p>
          <div className="grid md:grid-cols-3 gap-6">
            {plans.map((plan, index) => (
              <div
                key={index}
                className="border border-[#e5e5e5] p-8 text-center hover:border-[#c4a47c] transition-colors"
              >
                <h3 className="text-lg font-medium text-[#333] mb-2">{plan.name}</h3>
                <p className="text-[13px] text-[#666] mb-6">{plan.description}</p>
                <p className="text-[#999] text-sm line-through mb-1">通常 ¥{plan.regular}</p>
                <p className="text-[#c4a47c] mb-1">
                  <span className="text-sm">初月</span>
                  <span className="text-4xl font-light mx-1">¥{plan.campaign}</span>
                  <span className="text-sm">/月</span>
                </p>
                <p className="text-xs text-[#666]">（税込）</p>
              </div>
            ))}
          </div>
          <p className="text-center text-[13px] text-[#666] mt-8">
            ※2ヶ月目以降は通常料金となります。
            <br />
            ※他のキャンペーンとの併用はできません。
          </p>
        </div>
      </section>

      {/* Period Section */}
      <section className="py-20 md:py-28 bg-[#3d4a4f]">
        <div className="max-w-[800px] mx-auto px-6 text-center">
          <p className="text-[#c4a47c] text-sm tracking-[0.2em] mb-4">CAMPAIGN PERIOD</p>
          <h2 className="text-2xl md:text-3xl text-white tracking-wider mb-8">キャンペーン期間</h2>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-10 mb-8">
            <p className="text-white text-3xl md:text-4xl font-light tracking-wider">
              2025.4.1<span className="mx-4 text-xl">〜</span>2025.4.30
            </p>
          </div>
          <p className="text-white/70 text-sm leading-[2]">
            ※定員に達し次第、予告なく終了する場合がございます。
            <br />
            ※お早めのお申し込みをおすすめいたします。
          </p>
        </div>
      </section>

      {/* How to Apply Section */}
      <section className="py-20 md:py-28">
        <div className="max-w-[930px] mx-auto px-6">
          <h2 className="text-2xl md:text-3xl text-center text-[#3d4a4f] tracking-wider mb-16">お申し込み方法</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: "01", title: "無料体験予約", description: "まずは無料体験レッスンをご予約ください" },
              { step: "02", title: "体験レッスン", description: "実際にレッスンを体験していただきます" },
              { step: "03", title: "入会手続き", description: "体験後、入会手続きでキャンペーン適用" },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="text-[#c4a47c] text-5xl font-light mb-4">{item.step}</div>
                <h3 className="text-lg font-medium text-[#333] mb-3">{item.title}</h3>
                <p className="text-[14px] text-[#666]">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-[#f8f8f6]">
        <div className="max-w-[800px] mx-auto px-6 text-center">
          <h2 className="text-2xl md:text-3xl text-[#3d4a4f] tracking-wider mb-6">この春、新しい自分に出会おう</h2>
          <p className="text-[14px] leading-[2] text-[#666] mb-10">
            お得なキャンペーン期間中に、ぜひ無料体験レッスンにお越しください。
            <br />
            経験豊富なインストラクターがあなたをお待ちしています。
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/trial"
              className="inline-block bg-[#c4a47c] text-white px-12 py-5 text-sm tracking-wider hover:bg-[#b39369] transition-colors"
            >
              無料体験に申し込む
            </Link>
            <Link
              href="tel:03-0000-0000"
              className="inline-block bg-[#3d4a4f] text-white px-12 py-5 text-sm tracking-wider hover:bg-[#2d3a3f] transition-colors"
            >
              お電話でのお問い合わせ
            </Link>
          </div>
        </div>
      </section>

      <CtaBanner />
      <Footer />
    </>
  )
}
