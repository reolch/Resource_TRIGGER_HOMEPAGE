import Header from "@/components/header"
import Footer from "@/components/footer"
import CtaBanner from "@/components/cta-banner"
import Image from "next/image"
import Link from "next/link"
import { Check } from "lucide-react"

export default function TrialPage() {
  const benefits = [
    {
      title: "プロのインストラクターによる指導",
      description: "経験豊富なインストラクターが、一人ひとりのレベルに合わせて丁寧に指導します。",
    },
    {
      title: "手ぶらでOK",
      description: "マット、タオル、ウェアなど必要なものはすべてレンタル可能。気軽にお越しください。",
    },
    {
      title: "カウンセリング付き",
      description: "体験後にカウンセリングを行い、あなたに最適なプログラムをご提案します。",
    },
  ]

  const flow = [
    { step: "01", title: "ご予約", description: "お電話またはWebフォームからご予約ください" },
    { step: "02", title: "ご来店", description: "予約時間の15分前にお越しください" },
    { step: "03", title: "カウンセリング", description: "体調やご希望をお聞きします" },
    { step: "04", title: "体験レッスン", description: "約60分のレッスンを体験" },
    { step: "05", title: "アフターカウンセリング", description: "ご質問やプランのご相談" },
  ]

  return (
    <>
      <Header variant="light" />

      {/* Hero Section */}
      <section className="relative h-[70vh] min-h-[500px] flex items-center justify-center">
        <Image src="/yoga-class-women-smiling-stretching-studio-bright.jpg" alt="ヨガ基本コース無料体験" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-[#5a7a8a]/30" />
        <div className="relative z-10 text-center text-white px-4">
          <p className="text-sm md:text-base tracking-[0.2em] mb-4">心とカラダを整える、はじめの一歩</p>
          <h1 className="text-3xl md:text-5xl font-medium tracking-wider mb-8">ヨガ基本コース無料体験</h1>
          <Link
            href="/contact"
            className="inline-block bg-[#3d4a4f] text-white px-10 py-4 text-sm tracking-wider hover:bg-[#2d3a3f] transition-colors"
          >
            お申し込みはこちら
          </Link>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-20 md:py-28">
        <div className="max-w-[800px] mx-auto px-6">
          <p className="text-[15px] leading-[2.2] text-[#333] text-justify">
            日々のストレスや運動不足を感じていませんか？ヨガで心とカラダを整え、理想の自分に一歩近づきましょう。当スタジオでは、初心者の方でも安心して楽しめるヨガ基本コース無料体験をご用意しています。経験豊富なインストラクターが、一人ひとりに合わせた丁寧な指導を行いますので、無理なく始められます。
          </p>
        </div>
      </section>

      {/* Studio Image */}
      <section className="pb-20 md:pb-28">
        <div className="max-w-[800px] mx-auto px-6">
          <div className="relative aspect-[4/3]">
            <Image src="/woman-yoga-stretching-mat-foam-roller-studio-peace.jpg" alt="スタジオでのヨガ" fill className="object-cover" />
          </div>
          <p className="text-[15px] leading-[2.2] text-[#333] mt-10 text-justify">
            当スタジオは、清潔感のある広々とした空間で、リラックスしながらレッスンを受けられます。少人数制なので、一人ひとりに合わせた丁寧な指導が可能です。また、インストラクターは、ヨガやピラティスの専門知識を持ち、多くの指導経験があります。初心者の方もしっかりサポートいたします。
          </p>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 md:py-28 bg-[#f8f8f6]">
        <div className="max-w-[930px] mx-auto px-6">
          <h2 className="text-2xl md:text-3xl text-center text-[#3d4a4f] tracking-wider mb-16">体験レッスンの魅力</h2>
          <p className="text-[15px] leading-[2.2] text-[#333] text-center mb-16 max-w-[700px] mx-auto">
            ヨガに興味はあるけれど、「本当に自分に合っているのかな？」と不安な方も多いはず。そこで、当スタジオでは無料体験レッスンをご用意しました。
          </p>
          <div className="grid md:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="bg-white p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-[#c4a47c] flex items-center justify-center mx-auto mb-6">
                  <Check className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-medium text-[#333] mb-4">{benefit.title}</h3>
                <p className="text-[14px] leading-[1.9] text-[#666]">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Flow Section */}
      <section className="py-20 md:py-28">
        <div className="max-w-[930px] mx-auto px-6">
          <h2 className="text-2xl md:text-3xl text-center text-[#3d4a4f] tracking-wider mb-16">体験レッスンの流れ</h2>
          <div className="space-y-0">
            {flow.map((item, index) => (
              <div key={index} className="flex items-start border-b border-[#e5e5e5] py-8 first:border-t">
                <div className="text-[#c4a47c] text-3xl font-light mr-8 w-12">{item.step}</div>
                <div className="flex-1">
                  <h3 className="text-lg font-medium text-[#333] mb-2">{item.title}</h3>
                  <p className="text-[14px] text-[#666]">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 md:py-28 bg-[#f8f8f6]">
        <div className="max-w-[930px] mx-auto px-6">
          <h2 className="text-2xl md:text-3xl text-center text-[#3d4a4f] tracking-wider mb-16">体験レッスン料金</h2>
          <div className="bg-white p-10 md:p-14 text-center">
            <p className="text-[#c4a47c] text-sm tracking-wider mb-4">TRIAL LESSON</p>
            <p className="text-5xl md:text-6xl font-light text-[#333] mb-4">
              ¥<span className="text-6xl md:text-7xl">0</span>
            </p>
            <p className="text-[#666] text-sm mb-8">（税込）</p>
            <p className="text-[14px] leading-[1.9] text-[#666] mb-10">
              通常3,000円の体験レッスンが今なら無料！
              <br />
              マット・タオル・ウェアのレンタルも無料です。
            </p>
            <Link
              href="/contact"
              className="inline-block bg-[#c4a47c] text-white px-14 py-5 text-sm tracking-wider hover:bg-[#b39369] transition-colors"
            >
              無料体験に申し込む
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 md:py-28">
        <div className="max-w-[930px] mx-auto px-6">
          <h2 className="text-2xl md:text-3xl text-center text-[#3d4a4f] tracking-wider mb-16">よくあるご質問</h2>
          <div className="space-y-6">
            {[
              {
                q: "ヨガは初めてですが大丈夫ですか？",
                a: "はい、初心者の方でも安心してご参加いただけます。インストラクターが丁寧に指導いたします。",
              },
              {
                q: "持ち物は何が必要ですか？",
                a: "動きやすい服装でお越しください。マット、タオル、ウェアは無料でレンタル可能です。",
              },
              {
                q: "体験後に入会を強制されませんか？",
                a: "いいえ、体験後の入会は任意です。ご自身のペースでご検討ください。",
              },
              { q: "予約のキャンセルはできますか？", a: "前日までにご連絡いただければキャンセル可能です。" },
            ].map((faq, index) => (
              <div key={index} className="border-b border-[#e5e5e5] pb-6">
                <h3 className="text-[16px] font-medium text-[#333] mb-3 flex items-start">
                  <span className="text-[#c4a47c] mr-3">Q.</span>
                  {faq.q}
                </h3>
                <p className="text-[14px] leading-[1.9] text-[#666] pl-6">
                  <span className="text-[#3d4a4f] mr-1">A.</span>
                  {faq.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-[#3d4a4f]">
        <div className="max-w-[800px] mx-auto px-6 text-center">
          <h2 className="text-2xl md:text-3xl text-white tracking-wider mb-6">まずは無料体験から始めませんか？</h2>
          <p className="text-[14px] leading-[2] text-white/80 mb-10">
            ヨガで心とカラダを整え、健康で美しい毎日を手に入れましょう。
            <br />
            経験豊富なインストラクターがあなたをサポートします。
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/contact"
              className="inline-block bg-[#c4a47c] text-white px-12 py-5 text-sm tracking-wider hover:bg-[#b39369] transition-colors"
            >
              無料体験に申し込む
            </Link>
            <Link
              href="tel:03-0000-0000"
              className="inline-block bg-white text-[#3d4a4f] px-12 py-5 text-sm tracking-wider hover:bg-gray-100 transition-colors"
            >
              お電話でのお問い合わせ
            </Link>
          </div>
        </div>
      </section>

      <CtaBanner />
      <Footer />
    </>
  )
}
