import Header from "@/components/header"
import Footer from "@/components/footer"
import CtaBanner from "@/components/cta-banner"
import { ChevronRight } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

const staffMembers: Record<
  string,
  {
    name: string
    nameJa: string
    role: string
    roleEn: string
    image: string
    qualifications: string[]
    profile: string[]
    message: string[]
    instagram?: string
  }
> = {
  "yusei-yoshida": {
    name: "YUSEI YOSHIDA",
    nameJa: "吉田 悠成",
    role: "代表",
    roleEn: "REPRESENTATIVE",
    image: "https://smbtrfijdjwhfcqn.public.blob.vercel-storage.com/profile-yoshida-yusei.avif",
    qualifications: ["柔道整復師", "介護福祉士", "JATI日本認定トレーナー"],
    profile: [
      "宮崎にないものを作りたいという気持ちから、パーソナルジム×整体院の施設を作ろうと思い、この事業を立ち上げました。",
      "整骨院での実務経験もあり、トレーナーと治療家２つの目線で、お客様にとってどのトレーニングが最善でどの施術方法が最適なのかをご提案させて頂きます。",
    ],
    message: ["TRIGGERの魅力を存分にご堪能ください。"],
    instagram: "https://www.instagram.com/trigger_myzk2023/",
  },
  "ryosei-yoshinaga": {
    name: "RYOSEI YOSHINAGA",
    nameJa: "吉永 凉晴",
    role: "トレーナー兼整体施術",
    roleEn: "TRAINER & THERAPIST",
    image: "https://smbtrfijdjwhfcqn.public.blob.vercel-storage.com/profile-yoshinaga_ryosei.avif",
    qualifications: ["柔道整復師"],
    profile: [
      "宮崎市No. 1の施設を目指しています。",
      "国家資格である柔道整復師を保有しており、皆様のお身体を理想へ近づけます。",
    ],
    message: ["未来を１秒でも早く変化させましょう！"],
    instagram: "https://www.instagram.com/trigger_myzk_ryosei/",
  },
}

export async function generateStaticParams() {
  return Object.keys(staffMembers).map((slug) => ({ slug }))
}

export default async function StaffDetailPage({ params }: { params: { slug: string } }) {
  const { slug } = params
  const staff = staffMembers[slug]

  if (!staff) {
    return (
      <main className="min-h-screen">
        <Header variant="dark" />
        <div className="pt-32 pb-20 text-center">
          <h1 className="text-2xl">スタッフが見つかりません</h1>
        </div>
        <Footer />
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Banner */}
      <section className="relative h-[280px] md:h-[320px]">
        <Image src="/instructor-hero-yoga-women-class.jpg" alt="スタッフ" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          <p className="text-sm tracking-widest mb-2">スタッフ</p>
          <h1 className="text-3xl md:text-4xl font-light tracking-[0.3em]">STAFF</h1>
        </div>

        {/* Side Buttons */}
        <div className="hidden md:flex flex-col absolute right-0 top-1/2 -translate-y-1/2 z-20">
          <Link
            href="/trial"
            className="flex items-center justify-center text-white text-sm tracking-wider hover:opacity-80 transition-opacity"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
              backgroundColor: "#7b8d7b",
            }}
          >
            無料体験レッスン
          </Link>
          <Link
            href="/campaign"
            className="flex items-center justify-center text-white text-sm tracking-wider hover:opacity-80 transition-opacity"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
              backgroundColor: "#e8a598",
            }}
          >
            キャンペーン
          </Link>
        </div>
      </section>

      {/* Breadcrumb */}
      <div className="bg-[#f9f9f9] py-3">
        <div className="max-w-[1200px] mx-auto px-6">
          <nav className="flex items-center gap-2 text-sm text-gray-500">
            <Link href="/" className="hover:text-gray-700">
              HOME
            </Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-gray-700">{staff.name}</span>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <section className="py-16 md:py-20">
        <div className="max-w-[1200px] mx-auto px-6">
          {/* Name Header */}
          <div className="border border-gray-200 mb-12">
            <div className="flex justify-center pt-6">
              <div className="w-16 h-1 bg-[#c4a47c]" />
            </div>
            <div className="p-6 text-center">
              <h2 className="text-2xl md:text-3xl font-light tracking-widest text-[#3d4a4f]">{staff.nameJa}</h2>
            </div>
          </div>

          {/* Profile Section */}
          <div className="grid md:grid-cols-[400px_1fr] gap-10 md:gap-16">
            {/* Left - Image & Info */}
            <div>
              <div className="relative aspect-[3/4] mb-6">
                <Image
                  src={staff.image || "/placeholder.svg"}
                  alt={staff.name}
                  fill
                  className="object-cover"
                  priority
                />
              </div>
              {staff.instagram && (
                <div className="flex justify-center mb-6">
                  <a
                    href={staff.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="instagram"
                    className="text-[#3d4a4f] hover:text-[#c4a47c] transition-colors"
                  >
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225 1.664 4.771 4.919 4.919 1.266.058 1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.073-1.689-.073-4.948 0-3.204.013-3.663.072-4.948.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                    </svg>
                  </a>
                </div>
              )}
              <div className="border-b border-gray-200 pb-6 mb-6">
                <p className="text-sm text-[#c4a47c] mb-2">{staff.role}</p>
                <p className="text-lg text-gray-400 font-light tracking-wider">{staff.roleEn}</p>
              </div>
              <div>
                <h3 className="text-center text-sm font-semibold text-[#3d4a4f] mb-4 tracking-wider">保有資格</h3>
                <div className="space-y-3">
                  {staff.qualifications.map((qual, index) => (
                    <div
                      key={index}
                      className="bg-gradient-to-r from-[#f8f8f6] to-white border border-[#c4a47c]/30 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#c4a47c]/20 flex items-center justify-center">
                          <svg className="w-4 h-4 text-[#c4a47c]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                            />
                          </svg>
                        </div>
                        <p className="text-sm md:text-base text-[#3d4a4f] font-medium">{qual}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right - Text Content */}
            <div>
              <h3 className="text-xl text-[#3d4a4f] mb-4 pb-2 border-b border-[#c4a47c]">プロフィール</h3>
              <div className="mb-10">
                {staff.profile.map((text, index) => (
                  <p key={index} className="text-gray-600 leading-relaxed mb-4">
                    {text}
                  </p>
                ))}
              </div>

              <h3 className="text-xl text-[#3d4a4f] mb-4 pb-2 border-b border-[#c4a47c]">メッセージ</h3>
              <div>
                {staff.message.map((text, index) => (
                  <p key={index} className="text-gray-600 leading-relaxed mb-4">
                    {text}
                  </p>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <CtaBanner />
      <Footer />
    </main>
  )
}
