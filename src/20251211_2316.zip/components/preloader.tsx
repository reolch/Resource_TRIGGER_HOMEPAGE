"use client"

import { useEffect, useState } from "react"

export function Preloader() {
  const [fontLoaded, setFontLoaded] = useState(false)
  const [videoPreloaded, setVideoPreloaded] = useState(false)
  const [phase, setPhase] = useState<"loading" | "catchphrase" | "logo" | "fadeout" | "hidden">("loading")

  useEffect(() => {
    const checkFont = async () => {
      await document.fonts.ready
      // 追加の安全マージンを設けてフォントが完全に適用されるまで待つ
      await new Promise((resolve) => setTimeout(resolve, 100))
      setFontLoaded(true)
    }

    const preloadVideo = () => {
      const video = document.createElement("video")
      video.src = "https://smbtrfijdjwhfcqn.public.blob.vercel-storage.com/herosection-movie.mov"
      video.preload = "auto"
      video.muted = true

      const onCanPlay = () => {
        setVideoPreloaded(true)
        video.removeEventListener("canplaythrough", onCanPlay)
      }

      video.addEventListener("canplaythrough", onCanPlay)
      video.load()
    }

    checkFont()
    preloadVideo()
  }, [])

  useEffect(() => {
    if (!fontLoaded || !videoPreloaded) return

    const timers: NodeJS.Timeout[] = []

    // キャッチフレーズ表示開始
    timers.push(
      setTimeout(() => {
        setPhase("catchphrase")
      }, 100),
    )

    // ロゴに切り替え
    timers.push(
      setTimeout(() => {
        setPhase("logo")
      }, 1300),
    )

    // フェードアウト開始
    timers.push(
      setTimeout(() => {
        setPhase("fadeout")
      }, 2500),
    )

    // プリローダー非表示
    timers.push(
      setTimeout(() => {
        setPhase("hidden")
      }, 3100),
    )

    return () => timers.forEach((timer) => clearTimeout(timer))
  }, [fontLoaded, videoPreloaded])

  if (phase === "hidden") return null

  return (
    <div
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#7b8b8e] transition-opacity duration-[600ms] ${
        phase === "fadeout" ? "opacity-0" : "opacity-100"
      }`}
    >
      {fontLoaded && videoPreloaded && phase !== "loading" && (
        <>
          <div
            className={`absolute flex flex-col items-center text-center transition-all duration-500 ${
              phase === "catchphrase" ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"
            }`}
          >
            <span className="text-white text-[20px] md:text-[34px] tracking-[0.2em] leading-relaxed">
              「鍛える」×「整える」
            </span>
            <span className="text-white text-[20px] md:text-[34px] tracking-[0.2em] leading-relaxed">
              次世代型のパーソナルジム
            </span>
          </div>

          <div
            className={`absolute transition-all duration-500 ${
              phase === "logo"
                ? "opacity-100 translate-y-0"
                : phase === "catchphrase"
                  ? "opacity-0 translate-y-4"
                  : "opacity-0 -translate-y-4"
            }`}
          >
            <span className="text-white text-[28px] md:text-[42px] tracking-[0.4em] font-light">TRIGGER</span>
          </div>
        </>
      )}
    </div>
  )
}

export default Preloader
