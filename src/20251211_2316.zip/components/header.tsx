"use client"

import { useState, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { Search, X, ChevronDown } from "lucide-react"

const menuItems = [
  {
    label: "TRIGGERについて",
    href: "/about",
  },
  {
    label: "プログラム",
    href: "/program",
    isMegaMenu: true,
    subItems: [
      {
        label: "PERSONAL GYM",
        subLabel: "パーソナルジム",
        href: "/program/personal-gym",
        image: "/yoga-class-women-stretching.jpg",
        description: "プロトレーナーが多様なニーズに応えるオリジナルメニューをご提案",
      },
      {
        label: "SEITAI",
        subLabel: "整体",
        href: "/program/seitai",
        image: "/pilates-reformer-woman-exercise.jpg",
        description: "医師推薦・国家資格保有者による安心の整体施術をご提供します。",
      },
      {
        label: "ESTHETIC",
        subLabel: "エステ",
        href: "/program/esthetic",
        image: "/woman-yoga-stretching-fitness.jpg",
        description: "最新のラジオ波脂肪燃焼瘦身マシンを使った極上時間。",
      },
    ],
  },
  {
    label: "スタッフ",
    href: "/staff",
  },
  {
    label: "料金表",
    href: "/price",
    subItems: [{ label: "よくあるご質問", href: "/faq" }],
  },
  {
    label: "ブログ",
    href: "/blog",
  },
  {
    label: "お知らせ",
    href: "/news",
  },
]

interface HeaderProps {
  variant?: "light" | "dark"
}

export function Header({ variant = "light" }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [expandedMobileItem, setExpandedMobileItem] = useState<string | null>(null)
  const [activeMegaMenu, setActiveMegaMenu] = useState<string | null>(null)
  const pathname = usePathname()
  const closeTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  const isTopPage = pathname === "/"
  const effectiveVariant = isTopPage ? variant : "dark"
  const isLight = effectiveVariant === "light"

  const textColor = isLight ? "text-white" : "text-[#333]"
  const textColorMuted = isLight ? "text-white/90" : "text-[#555]"
  const lineColor = isLight ? "bg-white" : "bg-[#333]"
  const headerBg = isTopPage ? "" : "bg-white"

  const handleMenuEnter = (href: string) => {
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current)
      closeTimeoutRef.current = null
    }
    setActiveMegaMenu(href)
  }

  const handleMenuLeave = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setActiveMegaMenu(null)
    }, 150)
  }

  return (
    <header className={`absolute top-0 left-0 right-0 z-50 ${headerBg}`}>
      <div className="flex items-center justify-between px-6 md:px-10 lg:px-12 py-5">
        {/* Logo */}
        <Link href="/" className={`${textColor} text-lg tracking-[0.3em] font-light`}>
          TRIGGER
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-8">
          {menuItems.map((item) => (
            <div
              key={item.href}
              className="relative group"
              onMouseEnter={() => item.subItems && handleMenuEnter(item.href)}
              onMouseLeave={handleMenuLeave}
            >
              <Link
                href={item.href}
                className={`flex items-center gap-1 ${
                  pathname === item.href || pathname.startsWith(item.href + "/") || activeMegaMenu === item.href
                    ? isLight
                      ? "text-white"
                      : "text-[#c4a47c]"
                    : textColorMuted
                } text-[13px] tracking-wide hover:${isLight ? "text-white" : "text-[#c4a47c]"} transition-colors py-2`}
                onMouseEnter={() => item.subItems && handleMenuEnter(item.href)}
              >
                {item.label}
                {item.subItems && item.subItems.length > 0 && (
                  <ChevronDown size={12} className="transition-transform group-hover:rotate-180" />
                )}
              </Link>

              {/* メガメニュー */}
              {item.isMegaMenu && item.subItems && activeMegaMenu === item.href && (
                <div
                  className="fixed left-0 right-0 bg-[#8696a4] shadow-lg"
                  style={{ top: "70px" }}
                  onMouseEnter={() => handleMenuEnter(item.href)}
                  onMouseLeave={handleMenuLeave}
                >
                  <div className="absolute left-0 right-0 h-4 -top-4" />
                  <div className="max-w-[1200px] mx-auto py-10 px-8">
                    <div className="grid grid-cols-3 gap-8">
                      {item.subItems.map((subItem) => (
                        <Link key={subItem.href} href={subItem.href} className="group/item block">
                          {/* 画像 - 大きく表示 */}
                          <div className="relative aspect-[16/10] overflow-hidden mb-5">
                            <Image
                              src={subItem.image || "/placeholder.svg"}
                              alt={subItem.label}
                              fill
                              className="object-cover transition-transform duration-500 group-hover/item:scale-105"
                            />
                          </div>
                          {/* タイトル - 中央揃え白文字 */}
                          <h3 className="text-center text-[18px] tracking-[0.2em] text-white mb-3">{subItem.label}</h3>
                          {/* 説明文 - 中央揃え白文字 */}
                          <p className="text-center text-[13px] text-white/90 leading-relaxed">{subItem.description}</p>
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* 通常のドロップダウンメニュー */}
              {!item.isMegaMenu && item.subItems && item.subItems.length > 0 && activeMegaMenu === item.href && (
                <div
                  className="absolute top-full left-1/2 -translate-x-1/2 pt-2"
                  onMouseEnter={() => handleMenuEnter(item.href)}
                  onMouseLeave={handleMenuLeave}
                >
                  <div className="absolute left-0 right-0 h-2 -top-0" />
                  <div className="bg-white shadow-xl overflow-hidden" style={{ minWidth: "200px" }}>
                    {item.subItems.map((subItem, index) => (
                      <Link
                        key={subItem.href}
                        href={subItem.href}
                        className={`block px-5 py-3.5 text-[13px] text-[#555] hover:bg-[#f8f8f8] hover:text-[#c4a47c] transition-colors ${
                          index !== item.subItems!.length - 1 ? "border-b border-[#eee]" : ""
                        }`}
                      >
                        {subItem.label}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Right side icons */}
        <div className="flex items-center gap-4">
          <button className={`${textColorMuted} hover:${textColor} transition-colors`} aria-label="検索">
            <Search size={18} strokeWidth={1.5} />
          </button>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className={`lg:hidden ${textColor} p-2 flex flex-col gap-1.5`}
            aria-label="メニュー"
          >
            {isMenuOpen ? (
              <X size={24} />
            ) : (
              <>
                <span className={`block w-6 h-px ${lineColor}`} />
                <span className={`block w-6 h-px ${lineColor}`} />
                <span className={`block w-6 h-px ${lineColor}`} />
              </>
            )}
          </button>
        </div>
      </div>

      {/* Mobile menu overlay */}
      {isMenuOpen && (
        <div className="fixed inset-0 bg-[#7a8b8b]/95 z-40 flex items-center justify-center lg:hidden overflow-y-auto">
          <button
            onClick={() => setIsMenuOpen(false)}
            className="absolute top-6 right-6 text-white p-2"
            aria-label="閉じる"
          >
            <X size={28} />
          </button>
          <nav className="flex flex-col items-center gap-5 py-20">
            {menuItems.map((item) => (
              <div key={item.href} className="text-center">
                <div className="flex items-center justify-center gap-2">
                  <Link
                    href={item.href}
                    className="text-white text-xl tracking-widest hover:opacity-70 transition-opacity"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.label}
                  </Link>
                  {item.subItems && item.subItems.length > 0 && (
                    <button
                      onClick={() => setExpandedMobileItem(expandedMobileItem === item.href ? null : item.href)}
                      className="text-white/70 p-1"
                    >
                      <ChevronDown
                        size={16}
                        className={`transition-transform ${expandedMobileItem === item.href ? "rotate-180" : ""}`}
                      />
                    </button>
                  )}
                </div>
                {item.subItems && expandedMobileItem === item.href && (
                  <div className="mt-3 flex flex-col gap-2">
                    {item.subItems.map((subItem) => (
                      <Link
                        key={subItem.href}
                        href={subItem.href}
                        className="text-white/70 text-sm tracking-wide hover:text-white transition-colors"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        {subItem.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>
        </div>
      )}
    </header>
  )
}

export default Header
