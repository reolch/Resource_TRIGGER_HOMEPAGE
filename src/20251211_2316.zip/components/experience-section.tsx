import Image from "next/image"
import Link from "next/link"
import { ChevronRight } from "lucide-react"

export default function ExperienceSection() {
  return (
    <section className="relative min-h-[550px] lg:min-h-[650px] flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image src="/experience-yoga-beginner-woman-peaceful.jpg" alt="体験レッスン" fill className="object-cover" />
        <div className="absolute inset-0 bg-black/30" />
      </div>

      {/* Content - Left aligned */}
      <div className="relative z-10 w-full">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <div className="max-w-md lg:max-w-lg">
            <p className="text-[#c4a47c] text-[10px] tracking-[0.3em] mb-2">はじめての方へ</p>
            <h2 className="text-3xl lg:text-4xl font-extralight text-white tracking-[0.15em] mb-8">EXPERIENCE</h2>
            <p className="text-white/80 text-[13px] leading-[2] mb-8">
              私たちは初心者向けのクラスやサポート体制を充実させ、一人ひとりのペースに合わせたレッスンを行っています。まずは気軽に体験して、その心地よさを味わってみてください。経験豊富なインストラクターが、あなたの「はじめの一歩」を丁寧にサポートいたします。
            </p>
            <Link
              href="#"
              className="inline-flex items-center gap-2 text-[13px] text-white hover:text-[#c4a47c] transition-colors group border-b border-white pb-1"
            >
              <span>初回無料体験レッスン</span>
              <ChevronRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
