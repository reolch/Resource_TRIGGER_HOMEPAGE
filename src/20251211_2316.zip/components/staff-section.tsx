import Image from "next/image"
import Link from "next/link"
import { ChevronRight } from "lucide-react"

// <CHANGE> InstructorSectionをStaffSectionに変更
export default function StaffSection() {
  return (
    <section className="relative min-h-[550px] lg:min-h-[650px] flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0">
        {/* <CHANGE> altテキストをスタッフに変更 */}
        <Image src="/instructor-yoga-class-teaching-women.jpg" alt="スタッフ" fill className="object-cover" />
        <div className="absolute inset-0 bg-black/30" />
      </div>

      {/* Content - Right aligned */}
      <div className="relative z-10 w-full">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <div className="ml-auto max-w-md lg:max-w-lg text-right">
            {/* <CHANGE> インストラクターをスタッフに変更 */}
            <p className="text-[#c4a47c] text-[10px] tracking-[0.3em] mb-2">スタッフ</p>
            <h2 className="text-3xl lg:text-4xl font-extralight text-white tracking-[0.15em] mb-8">STAFF</h2>
            <p className="text-white/80 text-[13px] leading-[2] mb-8">
              経験豊富なスタッフが、一人ひとりの目標に寄り添い、パーソナルトレーニングと整体の本質を丁寧にお伝えします。お客様の悩みを考慮した、続けやすいプログラムで、心も体も自分らしく整えていきましょう。
            </p>
            {/* <CHANGE> リンク先をスタッフに変更 */}
            <Link
              href="/staff"
              className="inline-flex items-center gap-2 text-[13px] text-white hover:text-[#c4a47c] transition-colors group border-b border-white pb-1"
            >
              <span>スタッフ紹介</span>
              <ChevronRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
