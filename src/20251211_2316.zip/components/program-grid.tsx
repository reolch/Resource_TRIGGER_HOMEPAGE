import Image from "next/image"
import Link from "next/link"

const programs = [
  {
    href: "/program/personal-gym",
    image: "/yoga-class-woman-stretching-studio-green.jpg",
    subtitle: "パーソナルジム",
    title: "PERSONAL GYM",
    description:
      "プロのトレーナーがお客様のニーズに合わせたオリジナルメニューをご提案。お客様に合わせた多種多様なメニューをご用意しております。",
    overlayColor: "#00283f",
  },
  {
    href: "/program/seitai",
    image: "/pilates-woman-exercise-reformer-studio.jpg",
    subtitle: "整体",
    title: "SEITAI",
    description: "医師からも推薦を頂く整体施術。厚生労働省公認の国家資格保有者のみが在籍",
    overlayColor: "#230800",
  },
]

export default function ProgramGrid() {
  return (
    <section className="w-full">
      <div className="grid grid-cols-1 md:grid-cols-2">
        {programs.map((program, index) => (
          <Link key={index} href={program.href} className="group relative block overflow-hidden">
            {/* Image */}
            <div className="relative aspect-[725/570] w-full overflow-hidden">
              <Image
                src={program.image || "/placeholder.svg"}
                alt={program.title}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              {/* Overlay */}
              <div
                className="absolute inset-0 opacity-60 transition-opacity duration-300 group-hover:opacity-70"
                style={{ backgroundColor: program.overlayColor }}
              />
            </div>

            {/* Content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center text-white px-8 md:px-12">
              <p className="mb-2 text-sm tracking-widest">{program.subtitle}</p>
              <p className="mb-4 text-2xl md:text-2xl tracking-[0.3em] font-light">{program.title}</p>
              <p className="text-sm tracking-wide opacity-90 text-left max-w-md">{program.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}
