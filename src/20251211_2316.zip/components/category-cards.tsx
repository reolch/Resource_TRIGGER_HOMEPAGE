"use client"

import { ChevronRight } from "lucide-react"
import { useState } from "react"

interface Card {
  id: number
  label: string
  title: string
  highlight?: boolean
}

const cards: Card[] = [
  {
    id: 1,
    label: "はじめての方へ",
    title: "初回無料体験レッスン",
  },
  {
    id: 2,
    label: "今月のお得なキャンペーン",
    title: "初回会費・初月会費 0円",
    highlight: true,
  },
  {
    id: 3,
    label: "あなたに合ったエクササイズ",
    title: "レッスン・プログラム",
  },
]

export default function CategoryCards() {
  const [hoveredId, setHoveredId] = useState<number | null>(null)

  return (
    <section className="w-full bg-white">
      <div className="grid grid-cols-1 md:grid-cols-3">
        {cards.map((card, index) => (
          <div
            key={card.id}
            onMouseEnter={() => setHoveredId(card.id)}
            onMouseLeave={() => setHoveredId(null)}
            className={`relative group cursor-pointer transition-all duration-300 hover:bg-gray-50 ${
              index < cards.length - 1 ? "border-r border-gray-200" : ""
            }`}
          >
            <div className="px-8 md:px-10 py-10 md:py-12 flex items-center justify-between min-h-[120px]">
              <div className="flex-1">
                <p className="text-xs text-gray-500 mb-2 tracking-wide">{card.label}</p>
                <h3
                  className={`text-base md:text-lg tracking-wide ${
                    card.highlight ? "text-[#c17f6e]" : "text-gray-600"
                  }`}
                >
                  {card.title}
                </h3>
              </div>

              {/* Arrow icon */}
              <ChevronRight
                size={20}
                strokeWidth={1.5}
                className={`text-gray-400 transition-all duration-300 flex-shrink-0 ml-4 ${
                  hoveredId === card.id ? "translate-x-1 text-gray-600" : ""
                }`}
              />
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
