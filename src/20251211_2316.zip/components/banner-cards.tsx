import Image from "next/image"
import Link from "next/link"

const banners = [
  {
    label: "はじめての方へ",
    title: "初回無料体験レッスン",
    image: "/yoga-beginner-woman-peaceful-studio.jpg",
    href: "#",
  },
  {
    label: "今月のお得なキャンペーン",
    title: "初回会費・初月会費0円",
    image: "/pilates-woman-reformer-elegant-studio.jpg",
    href: "#",
  },
  {
    label: "あなたに合ったエクササイズ",
    title: "レッスン・プログラム",
    image: "/fitness-class-women-stretching-modern.jpg",
    href: "#",
  },
]

export default function BannerCards() {
  return (
    <section className="py-0 bg-background">
      <div className="grid grid-cols-1 md:grid-cols-3">
        {banners.map((banner, index) => (
          <Link key={index} href={banner.href} className="group relative overflow-hidden aspect-[4/3]">
            <Image
              src={banner.image || "/placeholder.svg"}
              alt={banner.title}
              fill
              className="object-cover transition-transform duration-700 group-hover:scale-105"
            />
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            {/* Content */}
            <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
              <p className="text-white/60 text-[10px] lg:text-xs tracking-wider mb-1">{banner.label}</p>
              <h3 className="text-white text-base lg:text-lg font-light tracking-wide">{banner.title}</h3>
            </div>
            {/* Hover line effect */}
            <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#c4a47c] transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
          </Link>
        ))}
      </div>
    </section>
  )
}
