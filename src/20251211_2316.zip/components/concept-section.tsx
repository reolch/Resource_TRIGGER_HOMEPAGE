export default function ConceptSection() {
  return (
    <section className="bg-white py-20 lg:py-28">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Main Title */}
        <div className="text-center mb-16">
          <h2 className="text-2xl lg:text-3xl font-light text-[#c4a47c] tracking-wide mb-3">鍛えて×整える</h2>
          <p className="text-2xl lg:text-3xl font-light text-[#c4a47c] tracking-wide">全てが揃う次世代パーソナルジム</p>
        </div>

        {/* Content Grid */}
        <div className="max-w-[900px] mx-auto space-y-8 text-center">
          <p className="text-[#333] text-lg lg:text-xl leading-relaxed">宮崎市で唯一パーソナルジムに整体院が併設。</p>

          <p className="text-[#333] text-lg lg:text-xl leading-relaxed">
            <span className="text-[#c4a47c] font-medium">「思いっきり鍛えて」</span>
            <span className="mx-2">×</span>
            <span className="text-[#c4a47c] font-medium">「しっかり整える」</span>
            <br />
            をコンセプトに掲げる。
          </p>

          <p className="text-[#666] text-base lg:text-lg leading-loose pt-4">
            厚生労働省公認の国家資格保有者の
            <br />
            精鋭のみが在籍。
          </p>

          <p className="text-[#666] text-base lg:text-lg leading-loose">
            お客様のお悩みを最短で解決。
            <br />
            人生の質を更に向上させます。
          </p>
        </div>
      </div>
    </section>
  )
}
