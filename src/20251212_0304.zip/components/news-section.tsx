"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"

const tabs = ["キャンペーン", "レッスン", "イベント"]

const newsData = {
  キャンペーン: [
    {
      date: "2025.02.02",
      category: "キャンペーン",
      title: "TRIGGERオリジナルグッズ販売スタート！",
      image: "/yoga-products-goods-store.jpg",
    },
    {
      date: "2024.11.16",
      category: "キャンペーン",
      title: "期間限定ペア割キャンペーン！お友達や家族と一緒にお得に参加",
      image: "/two-women-yoga-pair-friends.jpg",
    },
    {
      date: "2024.09.01",
      category: "キャンペーン",
      title: "ワークショップ「ヨガ×呼吸法」開催決定！",
      image: "/yoga-breathing-workshop-meditation.jpg",
    },
  ],
  レッスン: [
    {
      date: "2025.03.07",
      category: "レッスン",
      title: "夜のリラックスピラティス｜1日の疲れを癒すナイトプログラム登場！",
      image: "/night-pilates-relaxing-evening-class.jpg",
    },
    {
      date: "2024.11.22",
      category: "レッスン",
      title: "オンラインレッスン｜おうちでピラティス！",
      image: "/online-pilates-home-laptop-woman.jpg",
    },
    {
      date: "2024.08.11",
      category: "レッスン",
      title: "ピラティスの効果とは？ 身体の変化を実感できるレッスンのご紹介",
      image: "/pilates-effects-body-transformation.jpg",
    },
  ],
  イベント: [
    {
      date: "2025.02.26",
      category: "イベント",
      title: "インストラクター紹介｜TRIGGERのスペシャリスト",
      image: "/yoga-instructor-portrait-professional.jpg",
    },
    {
      date: "2024.12.03",
      category: "イベント",
      title: "ヨガとピラティスの違いは？それぞれの特徴を解説",
      image: "/yoga-vs-pilates-comparison.jpg",
    },
    {
      date: "2024.10.10",
      category: "イベント",
      title: "お客様の声｜TRIGGERで変わった私の毎日",
      image: "/customer-testimonial-happy-woman-fitness.jpg",
    },
  ],
}

const NewsSection = () => {
  const [activeTab, setActiveTab] = useState(tabs[0])

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-sm text-[#c4a47c] tracking-[0.2em] mb-2">お知らせ</p>
          <h2 className="text-4xl font-bold text-gray-900 mb-8">NEWS</h2>
        </div>

        <div className="flex justify-center gap-4 mb-12">
          {tabs.map((tab) => (
            <button
              key={tab}
              className={`px-8 py-3 rounded-full text-sm font-medium transition-all ${
                activeTab === tab ? "bg-black text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="space-y-6">
          {newsData[activeTab].map((news, index) => (
            <Link
              key={index}
              href={`/news/${news.category.toLowerCase()}/${index + 1}`}
              className="flex gap-6 group hover:opacity-80 transition-opacity"
            >
              {/* 修正点1: スマホで非表示、md以上で表示 */}
              <div className="relative w-[280px] h-[180px] flex-shrink-0 overflow-hidden hidden md:block"> 
                <Image
                  src={news.image || "/placeholder.svg"}
                  alt={news.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="flex-1 flex flex-col justify-center">
                <div className="flex items-center gap-4 mb-3">
                  <time className="text-sm text-gray-500">{news.date}</time>
                  <span className="px-3 py-1 bg-[#c4a47c] text-white text-xs rounded">{news.category}</span>
                </div>
                <h3 className="text-base font-medium text-gray-900 group-hover:text-[#c4a47c] transition-colors md:text-lg">
                  {news.title}
                </h3>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link
            href="/news"
            className="inline-block px-12 py-4 bg-black text-white text-sm font-medium hover:bg-gray-800 transition-colors"
          >
            お知らせ一覧
          </Link>
        </div>
      </div>
    </section>
  )
}

export default NewsSection
