import Image from "next/image";
import Link from "next/link";
import React from "react";

// バナーデータの型定義（TypeScriptを使用しない場合でも、構造を理解しやすくするためにコメントとして記載）
// interface LinkBanner {
//   title: string;
//   subtitle: string;
//   image: string;
//   href: string;
// }
// interface ThreeBannerProps {
//   linkBanners: LinkBanner[];
// }

export default function ThreeBanner({ linkBanners }) {
  // linkBannersが配列であることを確認する
  if (!linkBanners || linkBanners.length === 0) {
    return null; // データがない場合は何も表示しない
  }

  return (
    <section className="grid grid-cols-1 md:grid-cols-3">
      {linkBanners.map((banner, index) => (
        <Link
          // 複数のバナーが同じタイトルを持つ可能性を考慮し、indexをkeyに含めることを推奨します
          key={`${banner.title}-${index}`}
          href={banner.href}
          scroll={true}
          className="relative h-48 md:h-64 flex items-center justify-center group overflow-hidden"
        >
          <Image
            src={banner.image || "/placeholder.svg"}
            alt={banner.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            // priorityは3つのうち最初の一つにのみ適用することを検討しても良いですが、ここでは元のコードのまま維持します
            priority
          />
          {/* オーバーレイ */}
          <div className="absolute inset-0 bg-black/50 group-hover:bg-black/40 transition-colors" />
          
          {/* テキストコンテンツ */}
          <div className="relative z-10 text-center text-white">
            <p className="text-xs tracking-[0.2em] mb-2">{banner.subtitle}</p>
            <h3 className="text-2xl lg:text-3xl tracking-[0.15em] font-light">{banner.title}</h3>
          </div>
        </Link>
      ))}
    </section>
  );
}
