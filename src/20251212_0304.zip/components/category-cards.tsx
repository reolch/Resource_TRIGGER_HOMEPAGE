"use client"

import { ChevronRight } from "lucide-react"
import { useState } from "react"
import Link from "next/link" 

interface Card {
  id: number
  label: string
  title: string
  highlight?: boolean
  href: string
}

const cards: Card[] = [
  {
    id: 1,
    label: "はじめての方へ",
    title: "体験レッスン",
    href: "/trial",
  },
  {
    id: 2,
    label: "ホームページ限定",
    title: "キャンペーンについて",
    highlight: true,
    href: "/campaign",
  },
  {
    id: 3,
    label: "お客様にあった個別メニュー",
    title: "初回体験レッスン ￥2,980",
    href: "/price",
  },
]

export default function CategoryCards() {
  const [hoveredId, setHoveredId] = useState<number | null>(null)

  return (
    <section className="w-full bg-white hidden md:block"> 
      <div className="grid grid-cols-1 md:grid-cols-3">
        {cards.map((card, index) => {
          let titleColorClass = "text-gray-600";
          
          if (index === 0) {
            titleColorClass = "text-[#86957b]";
          } else if (index === 2) {
            titleColorClass = "text-[#a69280]";
          } else if (card.highlight) {
            titleColorClass = "text-[#c17f6e]";
          }

          return (
          <Link
            key={card.id}
            href={card.href}
            onMouseEnter={() => setHoveredId(card.id)}
            onMouseLeave={() => setHoveredId(null)}
            className={`relative group cursor-pointer transition-all duration-300 hover:bg-gray-50 ${
              index < cards.length - 1 ? "border-r border-gray-200" : ""
            }`}
          >
            <div className="px-8 md:px-10 py-10 md:py-12 flex items-center justify-between min-h-[120px]">
              <div className="flex-1">
                <p className="text-xs text-gray-500 mb-2 tracking-wide">{card.label}</p>
                <h3
                  className={`text-base md:text-lg tracking-wide ${titleColorClass}`}
                >
                  {card.title}
                </h3>
              </div>

              <ChevronRight
                size={20}
                strokeWidth={1.5}
                className={`text-gray-400 transition-all duration-300 flex-shrink-0 ml-4 ${
                  hoveredId === card.id ? "translate-x-1 text-gray-600" : ""
                }`}
              />
            </div>
          </Link>
          )
        })}
      </div>
    </section>
  )
}
