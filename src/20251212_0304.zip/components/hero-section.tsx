"use client"

import { useState, useEffect, useRef } from "react"
import { Play, Pause, Volume2, VolumeX, Clock } from "lucide-react"
import Link from "next/link"

type SlideItem = { type: "image"; src: string; alt: string } | { type: "video"; src: string; poster?: string }

const slides: SlideItem[] = [
  {
    type: "video",
    src: "https://smbtrfijdjwhfcqn.public.blob.vercel-storage.com/herosection-movie.mov",
    poster: "/yoga-studio-woman-meditation-gray-blue-elegant.jpg",
  },
  {
    type: "image",
    src: "/yoga-studio-woman-meditation-gray-blue-elegant.jpg",
    alt: "ヨガスタジオ",
  },
  {
    type: "image",
    src: "/fitness-woman-stretching-pilates-elegant-studio.jpg",
    alt: "フィットネス",
  },
  {
    type: "image",
    src: "/pilates-class-women-modern-studio-gray.jpg",
    alt: "ピラティスクラス",
  },
]

const newsItems = [
  { date: "2025.02.02", title: "TRIGGERオリジナルグッズ販売スタート！" },
  { date: "2025.01.15", title: "新春キャンペーン実施中" },
  { date: "2024.12.20", title: "年末年始の営業時間のお知らせ" },
]

export default function HeroSection() {
  const [isPlaying, setIsPlaying] = useState(true)
  const [isMuted, setIsMuted] = useState(true)
  const [currentNews, setCurrentNews] = useState(0)
  const [videoLoaded, setVideoLoaded] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    const newsInterval = setInterval(() => {
      setCurrentNews((prev) => (prev + 1) % newsItems.length)
    }, 4000)
    return () => clearInterval(newsInterval)
  }, [])

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const handleCanPlay = () => {
      setVideoLoaded(true)
    }

    video.addEventListener("canplaythrough", handleCanPlay)

    if (video.readyState >= 3) {
      setVideoLoaded(true)
    }

    return () => {
      video.removeEventListener("canplaythrough", handleCanPlay)
    }
  }, [])

  const togglePlay = () => {
    setIsPlaying(!isPlaying)
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
    }
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
    }
  }

  return (
    <section className="relative w-full h-screen overflow-hidden bg-[#8a9a9a]">
      <div className="absolute inset-0">
        {!videoLoaded && (
          <div
            className="absolute inset-0 w-full h-full bg-cover bg-center"
            style={{ backgroundImage: "url(/yoga-studio-woman-meditation-gray-blue-elegant.jpg)" }}
          />
        )}
        <video
          ref={videoRef}
          src="https://smbtrfijdjwhfcqn.public.blob.vercel-storage.com/herosection-movie.mov"
          poster="/yoga-studio-woman-meditation-gray-blue-elegant.jpg"
          autoPlay
          muted={isMuted}
          loop
          playsInline
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${
            videoLoaded ? "opacity-100" : "opacity-0"
          }`}
        />
      </div>

      {/* Overlay */}
      <div className="absolute inset-0 bg-black/10" />

      <div className="absolute inset-0 flex items-center justify-center">
        {/* Right column: 心とカラダを */}
        <div className="flex flex-row-reverse gap-6 md:gap-10">
          <div
            className="text-white text-2xl md:text-3xl lg:text-4xl font-light tracking-[0.2em] leading-[2]"
            style={{ writingMode: "vertical-rl" }}
          >
            心とカラダを
          </div>
          {/* Center column: 美しく鍛える */}
          <div
            className="text-white text-2xl md:text-3xl lg:text-4xl font-light tracking-[0.2em] leading-[2]"
            style={{ writingMode: "vertical-rl" }}
          >
            美しく鍛える
          </div>
          {/* Left column: ボディメイク。 */}
          <div
            className="text-white text-2xl md:text-3xl lg:text-4xl font-light tracking-[0.2em] leading-[2]"
            style={{ writingMode: "vertical-rl" }}
          >
            ボディメイク。
          </div>
        </div>
      </div>

      <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden md:flex flex-col z-20">
        <a 
          href="tel:070-0000-0000"
          className="bg-[#2a68a4] hover:bg-[#3d83c7] transition-colors text-white text-sm tracking-wider flex items-center justify-center"
          style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "160px",
          }}
        >
          電話で予約する
        </a>
        <Link
          href="https://line.me/R/ti/p/@841ytgtf"
          className="bg-[#00c300] hover:bg-[#10e310] transition-colors text-white text-sm tracking-wider flex items-center justify-center"
          style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "240px",
          }}
        >
          公式ラインで予約する
        </Link>
        <Link
          href="https://beauty.hotpepper.jp/kr/slnH000691057/"
          className="bg-[#e7c7ca] hover:bg-[#f2d7d9] transition-colors text-white text-sm tracking-wider flex items-center justify-center"
          style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "240px",
          }}
        >
          ホットペッパービューティー
        </Link>
      </div>

      <div className="absolute bottom-6 left-6">
        <Link
          href="/news"
          className="flex items-center gap-4 bg-white/20 backdrop-blur-md rounded-full px-6 py-3 hover:bg-white/30 transition-colors border border-white/20 shadow-lg"
        >
          <Clock size={16} className="text-white/80" />
          <span className="text-white/90 text-sm">{newsItems[currentNews].date}</span>
          <span className="text-white text-sm">{newsItems[currentNews].title}</span>
        </Link>
      </div>

      <div className="absolute bottom-20 left-1/2 -translate-x-1/2 flex items-center gap-6">
        {/* Play/Pause */}
        <button
          onClick={togglePlay}
          className="text-white/40 hover:text-white transition-colors"
          aria-label={isPlaying ? "一時停止" : "再生"}
        >
          {isPlaying ? <Pause size={14} /> : <Play size={14} />}
        </button>

        {/* Mute */}
        <button
          onClick={toggleMute}
          className="text-white/40 hover:text-white transition-colors"
          aria-label={isMuted ? "ミュート解除" : "ミュート"}
        >
          {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
        </button>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-20 right-10 hidden md:flex flex-col items-center">
        <span className="text-white/40 text-[10px] tracking-[0.2em]" style={{ writingMode: "vertical-rl" }}>
          SCROLL
        </span>
        <div className="w-px h-10 bg-white/20 mt-3" />
      </div>
    </section>
  )
}
