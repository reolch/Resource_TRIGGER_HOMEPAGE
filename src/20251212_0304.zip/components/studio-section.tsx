import Link from "next/link"

export default function StudioSection() {
  return (
    <section className="bg-[#f8f8f6] py-20 lg:py-28">
      <div className="max-w-[930px] mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <hgroup className="text-center mb-12">
          <p className="text-[#c4a47c] text-[11px] tracking-[0.2em] mb-2">特徴</p>
          <h2 className="text-3xl lg:text-4xl font-extralight text-[#333] tracking-[0.2em]">FEATURES</h2>
        </hgroup>

        {/* Content */}
        <div className="text-center">
          {/* Lead Title */}
          <p className="text-[#333] text-lg lg:text-xl font-light leading-relaxed mb-8">
            宮崎市神宮駅から徒歩3分圏内にある
            <br />
            パーソナルジム TRIGGER
          </p>

          {/* Description - PC */}
          <p className="hidden lg:block text-[#666] text-[14px] leading-[2.2] max-w-[800px] mx-auto mb-10">
            TRIGGERでは、従来の短期集中型パーソナルジムとは異なり、パーソナルジムがライフスタイルに組み込まれるよう目指しています。TRIGGERでは「パーソナルトレーニング」「国家資格保有者による整体施術」「痩身エステ」の3つのサービスを提供しています。
          </p>

          {/* Description - SP */}
          <p className="lg:hidden text-[#666] text-[13px] leading-[2] mb-10">
            TRIGGERでは、従来の短期集中型パーソナルジムとは異なり、パーソナルジムがライフスタイルに組み込まれるよう目指しています。
          </p>

          {/* CTA Button */}
          <div className="mt-12 lg:mt-16">
            <Link
              href="/about"
              className="inline-block border border-[#333] text-[#333] text-[13px] tracking-wider px-12 py-4 hover:bg-[#333] hover:text-white transition-colors duration-300"
            >
              TRIGGERについて
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
