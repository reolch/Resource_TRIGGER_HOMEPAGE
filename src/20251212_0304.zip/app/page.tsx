"use client"

import Preloader from "@/components/preloader"
import Header from "@/components/header"
import HeroSection from "@/components/hero-section"
import CategoryCards from "@/components/category-cards"
import BannerCards from "@/components/banner-cards"
import ConceptSection from "@/components/concept-section"
import StudioSection from "@/components/studio-section"
import StaffIntroSection from "@/components/staff-intro-section"
import PrideSection from "@/components/pride-section"
import ProgramGrid from "@/components/program-grid"
import NewsSection from "@/components/news-section"
import ExperienceSection from "@/components/experience-section"
import ThreeBanner from "@/components/three-banner"
import CTABanner from "@/components/cta-banner"
import Footer from "@/components/footer"

const mockLinkBanners = [
  {
    title: "体験レッスン",
    subtitle: "はじめての方へ",
    image: "https://raw.githubusercontent.com/reolch/Resource_TRIGGER_HOMEPAGE/refs/heads/main/three-banner/three-banner-1.jpg",
    href: "/trial",
  },
  {
    title: "最新情報",
    subtitle: "キャンペーン情報",
    image: "https://raw.githubusercontent.com/reolch/Resource_TRIGGER_HOMEPAGE/refs/heads/main/three-banner/three-banner-2.jpg",
    href: "/news",
  },
  {
    title: "プログラム",
    subtitle: "レッスンの種類",
    image: "https://raw.githubusercontent.com/reolch/Resource_TRIGGER_HOMEPAGE/refs/heads/main/three-banner/three-banner-3.jpg",
    href: "/program",
  },
];

export default function Home() {
  return (
    <>
      {/* Preloaderを表示 */}
      <Preloader />
      <main className="min-h-screen bg-background">
        <Header />
        <HeroSection />
        <CategoryCards />
        <BannerCards />
        <ConceptSection />
        <StudioSection />
        <StaffIntroSection />
        <PrideSection />
        <ProgramGrid />
        <NewsSection />
        <ExperienceSection />
        <ThreeBanner linkBanners={mockLinkBanners} />
        <Footer />
      </main>
    </>
  )
}
