import Header from "@/components/header"
import Footer from "@/components/footer"
import CTABanner from "@/components/cta-banner"
import Link from "next/link"
import Image from "next/image"

const subPrograms = [
  {
    id: "radio-wave",
    title: "ラジオ波痩身",
    subtitle: "脂肪燃焼を促進",
    description:
      "最新のラジオ波マシンを使用し、体の深部を温めることで脂肪燃焼を促進します。代謝アップ・セルライト改善・むくみ解消など、様々な効果が期待できます。",
    image: "/radio-wave-aesthetic-treatment-slimming-machine.jpg",
  },
  {
    id: "cavitation",
    title: "キャビテーション",
    subtitle: "部分痩せに効果的",
    description:
      "超音波の力で脂肪細胞を分解し、部分痩せを実現。気になる二の腕・太もも・お腹周りなど、ピンポイントでアプローチできます。痛みもなく、リラックスしながら施術を受けられます。",
    image: "/cavitation-aesthetic-treatment-body-slimming.jpg",
  },
  {
    id: "lymph-drainage",
    title: "リンパドレナージュ",
    subtitle: "デトックス効果",
    description:
      "リンパの流れを促進し、老廃物の排出をサポート。むくみ・冷え・疲労感の改善に効果的です。施術後はスッキリとした軽やかな体を実感していただけます。",
    image: "/lymph-drainage-massage-aesthetic-treatment.jpg",
  },
]

export default function EstheticPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Banner */}
      <section className="relative h-[400px] lg:h-[500px]">
        <Image src="/aesthetic-salon-treatment-luxurious-spa.jpg" alt="エステ" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-[#3d4a4f]/50" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center">
          <p className="text-sm tracking-[0.3em] mb-2">エステ</p>
          <h1 className="text-4xl lg:text-5xl tracking-[0.2em] font-light">ESTHETIC</h1>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden lg:flex flex-col z-20">
          <Link
            href="/trial"
            className="flex items-center justify-center text-white text-sm tracking-widest bg-[#6b7c7f] hover:bg-[#5a6a6e] transition-colors"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            無料体験レッスン
          </Link>
          <Link
            href="/campaign"
            className="flex items-center justify-center text-white text-sm tracking-widest bg-[#e8a598] hover:bg-[#d99588] transition-colors"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            キャンペーン
          </Link>
        </div>
      </section>

      {/* Breadcrumb */}
      <div className="bg-[#f8f8f6] py-3 px-4">
        <div className="max-w-[1200px] mx-auto">
          <nav className="text-xs text-[#888]">
            <Link href="/" className="hover:text-[#c4a47c]">
              ホーム
            </Link>
            <span className="mx-2">/</span>
            <Link href="/program" className="hover:text-[#c4a47c]">
              プログラム
            </Link>
            <span className="mx-2">/</span>
            <span className="text-[#3d4a4f]">エステ</span>
          </nav>
        </div>
      </div>

      {/* Intro Section */}
      <section className="py-20 lg:py-28 px-4">
        <div className="max-w-[930px] mx-auto text-center">
          <p className="text-[#c4a47c] text-lg tracking-[0.3em] mb-4">極上のリラクゼーション</p>
          <h2 className="text-2xl lg:text-3xl text-[#3d4a4f] tracking-[0.1em] mb-8 leading-relaxed">
            最新のラジオ波脂肪燃焼痩身マシンを使った
            <br />
            極上時間
          </h2>
          <p className="text-[#666] leading-relaxed text-sm lg:text-base hidden lg:block">
            TRIGGERでは、パーソナルトレーニング・整体に加えて、最新のエステマシンによる痩身メニューもご用意しています。
            <br />
            ラジオ波やキャビテーションなど、科学的根拠に基づいた施術で、トレーニングだけでは難しい部分痩せやボディラインの調整をサポート。
            <br />
            「鍛える」×「整える」×「美しく」の3つのアプローチで、あなたの理想のボディを実現します。
          </p>
          <p className="text-[#666] leading-relaxed text-sm lg:hidden">
            最新のエステマシンによる痩身メニューをご用意。トレーニングだけでは難しい部分痩せやボディラインの調整をサポートします。
          </p>
        </div>
      </section>

      {/* Sub Programs */}
      <section className="pb-20 lg:pb-28">
        {subPrograms.map((program, index) => (
          <div
            key={program.id}
            id={program.id}
            className={`flex flex-col ${index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"}`}
          >
            <div className="relative w-full lg:w-1/2 h-[300px] lg:h-[500px]">
              <Image src={program.image || "/placeholder.svg"} alt={program.title} fill className="object-cover" />
            </div>
            <div className="w-full lg:w-1/2 flex items-center justify-center p-8 lg:p-16 bg-[#f8f8f6]">
              <div className="max-w-[450px]">
                <p className="text-[#c4a47c] text-sm tracking-[0.2em] mb-2">{program.subtitle}</p>
                <h3 className="text-2xl lg:text-3xl text-[#3d4a4f] tracking-[0.1em] mb-6">{program.title}</h3>
                <p className="text-[#666] text-sm lg:text-base leading-relaxed">{program.description}</p>
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Price Link Section */}
      <section className="py-16 bg-[#3d4a4f] text-center">
        <p className="text-white/80 text-sm mb-4">料金について詳しく知りたい方はこちら</p>
        <Link
          href="/price"
          className="inline-flex items-center justify-center gap-2 px-12 py-4 bg-white text-[#3d4a4f] text-sm tracking-wider hover:bg-[#f8f8f6] transition-colors"
        >
          料金表を見る
        </Link>
      </section>

      <CTABanner />
      <Footer />
    </div>
  )
}
