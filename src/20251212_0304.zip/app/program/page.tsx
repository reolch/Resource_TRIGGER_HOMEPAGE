import Header from "@/components/header"
import Footer from "@/components/footer"
import CTABanner from "@/components/cta-banner"
import Link from "next/link"
import Image from "next/image"

const programs = [
  {
    id: "yoga",
    subtitle: "ヨガ",
    title: "YOGA",
    image: "/program-yoga-woman-stretching-mat.jpg",
    description:
      "ヨガは、古代インド発祥の心身を整えるためのメソッドであり、呼吸・瞑想・ポーズ（アーサナ）を組み合わせることで、心と体のバランスを整えることを目的としています。単なる運動ではなく、深い呼吸を意識しながらゆっくりと体を動かすことで、リラックス効果を高め、ストレスを軽減することができます。柔軟性の向上や筋力強化にも効果的です。",
    subProgram: {
      title: "ホットヨガ",
      subtitle: "発汗を促し体をほぐす",
      description:
        "ホットヨガは、温度35〜40℃、湿度50〜60％の環境で行うヨガのスタイルで、発汗を促しながら体をしっかりと伸ばし、筋肉をほぐしていくことが特徴です。温かい環境の中で行うことで、筋肉が柔らかくなり、関節の可動域が広がるため、初心者の方でも無理...",
    },
    href: "/program/yoga",
  },
  {
    id: "pilates",
    subtitle: "ピラティス",
    title: "PILATES",
    image: "/program-pilates-woman-reformer.jpg",
    description:
      "ピラティスは、体幹（コア）を鍛えながら姿勢を整え、しなやかで強い体を作ることを目的としています。ピラティスの大きな魅力は、「体の内側から鍛えられる」こと。深い呼吸とともにインナーマッスルを意識して動かすことで、筋力・柔軟性・バランス感覚を向上させ、日常生活の姿勢改善や運動パフォーマンスの向上につながります。",
    subProgram: {
      title: "マットピラティス",
      subtitle: "ピラティスの基本を学ぶ",
      description:
        "マットピラティスは、専用のマットを使用して行うピラティスの基本的なプログラムです。自分の体重を利用してコア（体幹）を強化し、姿勢の改善や柔軟性の向上を目指します。初心者の方でも無理なく取り組めるよう、シンプルな動きからスタートし、徐々にレベルアップ...",
    },
    href: "/program/pilates",
  },
]

export default function ProgramPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Banner */}
      <section className="relative h-[400px] lg:h-[500px]">
        <Image src="/program-hero-yoga-women-class.jpg" alt="プログラム" fill className="object-cover" priority />
        <div className="absolute inset-0 bg-[#5a6a6e]/40" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center">
          <p className="text-sm tracking-[0.3em] mb-2">プログラム</p>
          <h1 className="text-4xl lg:text-5xl tracking-[0.2em] font-light">PROGRAM</h1>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden lg:flex flex-col z-20">
          <Link
            href="/trial"
            className="flex items-center justify-center text-white text-sm tracking-widest bg-[#6b7c7f] hover:bg-[#5a6a6e] transition-colors"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
            }}
          >
            無料体験レッスン
          </Link>
          <Link
            href="/reserve"
            className="flex items-center justify-center text-white text-sm tracking-widest bg-[#e8a598] hover:bg-[#d99588] transition-colors"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "180px",
            }}
          >
            レッスン予約
          </Link>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-20 lg:py-28 px-4">
        <div className="max-w-[930px] mx-auto text-center">
          <p className="text-[#c4a47c] text-lg tracking-[0.3em] mb-4">ヨガ＆ピラティス</p>
          <h2 className="text-2xl lg:text-3xl text-[#3d4a4f] tracking-[0.2em] mb-8">カラダとココロを鍛える</h2>
          <p className="text-[#666] leading-relaxed text-sm lg:text-base">
            基礎から高度なコア強化や柔軟性アップまで、段階的に学べるコースをご用意。
            <br className="hidden lg:block" />
            初心者から経験者まで無理なく継続できるので、ご自身にあったペースで健康的な身体を目指せます。
          </p>
        </div>
      </section>

      {/* Program Cards */}
      <section className="pb-20 lg:pb-28 px-4">
        <div className="max-w-[900px] mx-auto space-y-16">
          {programs.map((program, index) => (
            <article key={program.id} className="bg-white border border-gray-100 shadow-sm">
              <div className="relative h-[250px] lg:h-[380px] overflow-hidden">
                <Image
                  src={program.image || "/placeholder.svg"}
                  alt={program.title}
                  fill
                  className="object-cover"
                  priority={index < 2}
                />
              </div>

              <div className="p-8 lg:p-12 text-center">
                <p className="text-[#666] text-sm mb-2">{program.subtitle}</p>
                <h3 className="text-3xl lg:text-4xl text-[#c4a47c] tracking-[0.15em] mb-6">{program.title}</h3>
                <p className="text-[#666] text-sm lg:text-base leading-relaxed mb-8 max-w-[700px] mx-auto">
                  {program.description}
                </p>

                <div className="border-t border-gray-200 pt-8 mt-8 text-left">
                  <div className="flex items-center gap-3 mb-3">
                    <h4 className="text-lg text-[#3d4a4f] font-medium">{program.subProgram.title}</h4>
                    <span className="text-[#c4a47c] text-sm">{program.subProgram.subtitle}</span>
                  </div>
                  <p className="text-[#666] text-sm leading-relaxed">{program.subProgram.description}</p>
                </div>

                <Link
                  href={program.href}
                  className="inline-flex items-center justify-center gap-2 mt-10 px-12 py-4 bg-[#6b7c7f] text-white text-sm tracking-wider hover:bg-[#5a6a6e] transition-colors"
                >
                  もっと見る
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <CTABanner />
      <Footer />
    </div>
  )
}
