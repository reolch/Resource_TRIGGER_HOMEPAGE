import Image from "next/image"
import Link from "next/link"

const staffMembers = [
  {
    id: "yusei-yoshida",
    name: "吉田 悠成",
    role: "代表",
    image: "https://smbtrfijdjwhfcqn.public.blob.vercel-storage.com/profile-yoshida-yusei.avif",
    description:
      "宮崎にないものを作りたいという気持ちから、パーソナルジム×整体院の施設を作ろうと思い、この事業を立ち上げました。",
  },
  {
    id: "ryosei-yoshinaga",
    name: "吉永 凉晴",
    role: "トレーナー兼整体",
    image: "https://smbtrfijdjwhfcqn.public.blob.vercel-storage.com/profile-yoshinaga_ryosei.avif",
    description:
      "宮崎市No.1の施設を目指しています。国家資格である柔道整復師を保有しており、皆様のお身体を理想へ近づけます。",
  },
]

export default function StaffIntroSection() {
  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <p className="text-[#c4a47c] text-[11px] tracking-[0.3em] mb-3">スタッフ紹介</p>
          <h2 className="text-3xl lg:text-4xl font-extralight tracking-[0.15em] text-[#333]">STAFF</h2>
        </div>

        {/* Staff Members */}
        <div className="space-y-20 lg:space-y-28">
          {staffMembers.map((staff, index) => (
            <div
              key={staff.id}
              className={`flex flex-col ${index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"} gap-10 lg:gap-16 items-center`}
            >
              {/* Image */}
              <div className="w-full lg:w-1/2">
                <div className="relative aspect-[4/5] overflow-hidden">
                  <Image src={staff.image || "/placeholder.svg"} alt={staff.name} fill className="object-cover" />
                </div>
              </div>

              {/* Content */}
              <div className="w-full lg:w-1/2">
                <p className="text-[#c4a47c] text-[11px] tracking-[0.2em] mb-3">{staff.role}</p>
                <h3 className="text-2xl lg:text-3xl font-light tracking-wider text-[#333] mb-6">{staff.name}</h3>
                <div className="w-12 h-px bg-[#c4a47c] mb-6" />
                <p className="text-[#666] text-[14px] leading-[2] mb-8">{staff.description}</p>
                <Link
                  href={`/staff/${staff.id}`}
                  className="inline-block text-[13px] text-[#333] border-b border-[#333] pb-1 hover:text-[#c4a47c] hover:border-[#c4a47c] transition-colors"
                >
                  続きを見る
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
