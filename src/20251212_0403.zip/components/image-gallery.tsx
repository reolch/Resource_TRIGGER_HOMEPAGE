"use client"

const galleryImages = [
  {
    id: 1,
    src: "/woman-yoga-stretching-pink-top-fitness.jpg",
    alt: "ヨガストレッチ",
  },
  {
    id: 2,
    src: "/woman-fitness-training-side-profile-athletic.jpg",
    alt: "フィットネストレーニング",
  },
  {
    id: 3,
    src: "/two-women-pilates-stretching-class-gray-tank-top.jpg",
    alt: "ピラティスクラス",
  },
  {
    id: 4,
    src: "/fitness-gym-equipment-training-machine-close-up.jpg",
    alt: "ジム設備",
  },
  {
    id: 5,
    src: "/woman-pilates-reformer-exercise-studio.jpg",
    alt: "ピラティスリフォーマー",
  },
]

export default function ImageGallery() {
  return (
    <section className="w-full">
      <div className="grid grid-cols-2 md:grid-cols-5">
        {galleryImages.map((img) => (
          <div key={img.id} className="relative aspect-square overflow-hidden group cursor-pointer">
            <img
              src={img.src || "/placeholder.svg"}
              alt={img.alt}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300" />
          </div>
        ))}
      </div>
    </section>
  )
}
