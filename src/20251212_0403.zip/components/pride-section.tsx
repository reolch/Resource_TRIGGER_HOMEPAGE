export function PrideSection() {
  return (
    <section className="relative py-20 lg:py-28">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* 左側：画像 */}
          <div className="relative aspect-[4/3] overflow-hidden rounded-lg">
            <img
              src="/images/design-mode/banner-cards-1.avif"
              alt="選ばれる理由"
              className="w-full h-full object-cover"
            />
          </div>

          {/* 右側：コンテンツ */}
          <div className="space-y-6">
            <div>
              <p className="text-[#c4a47c] text-sm lg:text-base font-light tracking-wider mb-3">選ばれる理由</p>
              <h2 className="text-3xl lg:text-4xl font-light tracking-wider mb-6">PRIDE</h2>
            </div>

            <p className="text-base lg:text-lg leading-relaxed text-gray-700">なぜTRIGGERが選ばれるのか。</p>

            <a
              href="/trial"
              className="inline-block bg-[#3d4a4f] text-white px-8 py-4 hover:bg-[#2d3a3f] transition-colors duration-300"
            >
              Before/Afterを見る
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

export default PrideSection
