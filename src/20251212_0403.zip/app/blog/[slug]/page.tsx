import Header from "@/components/header"
import Footer from "@/components/footer"
import CTABanner from "@/components/cta-banner"
import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { getBlogPost, getRelatedPosts, blogPosts } from "@/lib/blog-posts"

export function generateStaticParams() {
  return blogPosts.map((post) => ({
    slug: post.slug,
  }))
}

export default async function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const post = getBlogPost(slug)

  if (!post) {
    notFound()
  }

  const relatedPosts = post.relatedPosts ? getRelatedPosts(post.relatedPosts) : []

  return (
    <main className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Banner */}
      <section className="relative h-[50vh] min-h-[400px]">
        <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          <p className="text-sm tracking-[0.3em] mb-3">ブログ</p>
          <h1 className="text-4xl md:text-5xl tracking-[0.2em] font-light">BLOG</h1>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden md:flex flex-col z-10">
          <Link
            href="/trial"
            className="bg-[#7b8d7b] text-white flex items-center justify-center hover:opacity-90 transition-opacity"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            <span className="text-sm tracking-[0.2em]">無料体験レッスン</span>
          </Link>
          <Link
            href="/reserve"
            className="bg-[#e8b4b4] text-white flex items-center justify-center hover:opacity-90 transition-opacity"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            <span className="text-sm tracking-[0.2em]">レッスン予約</span>
          </Link>
        </div>
      </section>

      {/* Breadcrumb */}
      <div className="bg-[#f8f8f6] py-3">
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="flex items-center gap-2 text-xs text-[#888]">
            <Link href="/" className="hover:text-[#c4a47c]">
              HOME
            </Link>
            <span>/</span>
            <Link href="/blog" className="hover:text-[#c4a47c]">
              ブログ
            </Link>
            <span>/</span>
            <span className="text-[#333] line-clamp-1">{post.title}</span>
          </div>
        </div>
      </div>

      {/* Article */}
      <article className="py-16 px-6">
        <div className="max-w-[800px] mx-auto">
          {/* Article Header */}
          <header className="mb-12">
            <div className="flex items-center gap-4 mb-6">
              <span className="bg-[#c4a47c] text-white text-xs px-4 py-1">{post.category}</span>
              <time className="text-sm text-[#999] flex items-center gap-1">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="10" strokeWidth="1.5" />
                  <path strokeWidth="1.5" d="M12 6v6l4 2" />
                </svg>
                {post.date}
              </time>
            </div>
            <h1 className="text-2xl md:text-3xl text-[#333] leading-relaxed font-medium">{post.title}</h1>
          </header>

          {/* Featured Image */}
          <div className="relative aspect-[16/9] mb-12">
            <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
          </div>

          {/* Article Content */}
          <div
            className="prose prose-lg max-w-none mb-16
              prose-headings:text-[#333] prose-headings:font-medium
              prose-h2:text-xl prose-h2:mt-12 prose-h2:mb-6 prose-h2:pb-3 prose-h2:border-b prose-h2:border-[#e5e5e5]
              prose-h3:text-lg prose-h3:mt-8 prose-h3:mb-4
              prose-p:text-[#555] prose-p:leading-loose prose-p:mb-6
              prose-li:text-[#555] prose-li:leading-loose
              prose-ol:my-6 prose-ul:my-6
              prose-strong:text-[#333] prose-strong:font-medium"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />

          {/* Author */}
          <div className="border-t border-b border-[#e5e5e5] py-8 mb-16">
            <div className="flex items-center gap-6">
              <div className="relative w-20 h-20 rounded-full overflow-hidden shrink-0">
                <Image
                  src={post.author.image || "/placeholder.svg"}
                  alt={post.author.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <p className="text-xs text-[#999] mb-1">この記事を書いた人</p>
                <p className="text-lg text-[#333] font-medium mb-1">{post.author.name}</p>
                <p className="text-sm text-[#666]">{post.author.role}</p>
              </div>
            </div>
          </div>

          {/* Share */}
          <div className="mb-16">
            <p className="text-sm text-[#666] mb-4">この記事をシェアする</p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-10 h-10 bg-[#1DA1F2] text-white rounded-full flex items-center justify-center hover:opacity-80 transition-opacity"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-[#1877F2] text-white rounded-full flex items-center justify-center hover:opacity-80 transition-opacity"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-[#00B900] text-white rounded-full flex items-center justify-center hover:opacity-80 transition-opacity"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314" />
                </svg>
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between items-center border-t border-[#e5e5e5] pt-8 mb-16">
            <Link
              href="/blog"
              className="flex items-center gap-2 text-sm text-[#666] hover:text-[#c4a47c] transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
              記事一覧に戻る
            </Link>
          </div>

          {/* Related Posts */}
          {relatedPosts.length > 0 && (
            <section>
              <h2 className="text-xl text-[#333] font-medium mb-8 pb-3 border-b border-[#e5e5e5]">関連記事</h2>
              <div className="grid md:grid-cols-2 gap-6">
                {relatedPosts.map((relatedPost) => (
                  <Link key={relatedPost.id} href={`/blog/${relatedPost.slug}`} className="group block">
                    <article className="flex gap-4">
                      <div className="relative w-28 h-28 shrink-0 overflow-hidden">
                        <Image
                          src={relatedPost.image || "/placeholder.svg"}
                          alt={relatedPost.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                      <div className="flex flex-col justify-center">
                        <span className="text-xs text-[#c4a47c] mb-1">{relatedPost.category}</span>
                        <h3 className="text-sm text-[#333] leading-relaxed group-hover:text-[#c4a47c] transition-colors line-clamp-2">
                          {relatedPost.title}
                        </h3>
                        <time className="text-xs text-[#999] mt-2">{relatedPost.date}</time>
                      </div>
                    </article>
                  </Link>
                ))}
              </div>
            </section>
          )}
        </div>
      </article>

      <CTABanner />
      <Footer />
    </main>
  )
}
