import Header from "@/components/header"
import Footer from "@/components/footer"
import CTABanner from "@/components/cta-banner"
import Image from "next/image"
import Link from "next/link"
import { blogPosts } from "@/lib/blog-posts"

const categories = [
  { id: "all", label: "すべて" },
  { id: "yoga", label: "ヨガ" },
  { id: "pilates", label: "ピラティス" },
  { id: "health", label: "健康" },
  { id: "lifestyle", label: "ライフスタイル" },
]

export default function BlogPage() {
  return (
    <main className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Banner */}
      <section className="relative h-[50vh] min-h-[400px]">
        <Image
          src="/yoga-studio-peaceful-meditation-women-class.jpg"
          alt="ブログ"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          <p className="text-sm tracking-[0.3em] mb-3">ブログ</p>
          <h1 className="text-4xl md:text-5xl tracking-[0.2em] font-light">BLOG</h1>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden md:flex flex-col z-10">
          <Link
            href="/trial"
            className="bg-[#7b8d7b] text-white flex items-center justify-center hover:opacity-90 transition-opacity"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            <span className="text-sm tracking-[0.2em]">無料体験レッスン</span>
          </Link>
          <Link
            href="/reserve"
            className="bg-[#e8b4b4] text-white flex items-center justify-center hover:opacity-90 transition-opacity"
            style={{ writingMode: "vertical-rl", width: "70px", height: "180px" }}
          >
            <span className="text-sm tracking-[0.2em]">レッスン予約</span>
          </Link>
        </div>
      </section>

      {/* Breadcrumb */}
      <div className="bg-[#f8f8f6] py-3">
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="flex items-center gap-2 text-xs text-[#888]">
            <Link href="/" className="hover:text-[#c4a47c]">
              HOME
            </Link>
            <span>/</span>
            <span className="text-[#333]">ブログ</span>
          </div>
        </div>
      </div>

      {/* Introduction */}
      <section className="py-20 px-6">
        <div className="max-w-[800px] mx-auto text-center">
          <h2 className="text-2xl md:text-3xl text-[#333] mb-6 leading-relaxed">
            トレーニング＆整体の知識や
            <br className="md:hidden" />
            ライフスタイルに役立つ情報を発信
          </h2>
          <p className="text-[#666] text-sm leading-loose">
            TRIGGERのトレーナーが、パーソナルトレーニングや整体の基礎知識から上級テクニック、
            健康的なライフスタイルのヒントまで、皆さまの毎日に役立つ情報をお届けします。
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="pb-10 px-6">
        <div className="max-w-[1200px] mx-auto">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category, index) => (
              <button
                key={category.id}
                className={`px-6 py-2 text-sm rounded-full transition-colors ${
                  index === 0 ? "bg-[#333] text-white" : "bg-[#f5f5f3] text-[#666] hover:bg-[#333] hover:text-white"
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="pb-20 px-6">
        <div className="max-w-[1200px] mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <Link key={post.id} href={`/blog/${post.slug}`} className="group block">
                <article className="bg-white">
                  <div className="relative aspect-[3/2] overflow-hidden mb-4">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <span className="absolute top-3 left-3 bg-[#c4a47c] text-white text-xs px-3 py-1">
                      {post.category}
                    </span>
                  </div>
                  <div className="px-1">
                    <time className="text-xs text-[#999] flex items-center gap-1 mb-2">
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="10" strokeWidth="1.5" />
                        <path strokeWidth="1.5" d="M12 6v6l4 2" />
                      </svg>
                      {post.date}
                    </time>
                    <h3 className="text-[#333] text-base leading-relaxed mb-3 group-hover:text-[#c4a47c] transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-[#888] text-xs leading-relaxed line-clamp-2">{post.excerpt}</p>
                  </div>
                </article>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Pagination */}
      <section className="pb-20 px-6">
        <div className="max-w-[1200px] mx-auto">
          <div className="flex justify-center items-center gap-2">
            <span className="w-10 h-10 flex items-center justify-center bg-[#333] text-white text-sm">1</span>
            <Link
              href="#"
              className="w-10 h-10 flex items-center justify-center bg-[#f5f5f3] text-[#666] text-sm hover:bg-[#333] hover:text-white transition-colors"
            >
              2
            </Link>
            <Link
              href="#"
              className="w-10 h-10 flex items-center justify-center bg-[#f5f5f3] text-[#666] text-sm hover:bg-[#333] hover:text-white transition-colors"
            >
              3
            </Link>
            <span className="text-[#999] px-2">...</span>
            <Link
              href="#"
              className="w-10 h-10 flex items-center justify-center bg-[#f5f5f3] text-[#666] text-sm hover:bg-[#333] hover:text-white transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        </div>
      </section>

      <CTABanner />
      <Footer />
    </main>
  )
}
