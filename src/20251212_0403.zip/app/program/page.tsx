import Header from "@/components/header"
import Footer from "@/components/footer"
import CTABanner from "@/components/cta-banner"
import Link from "next/link"
import Image from "next/image"

const programs = [
  {
    id: "personal-training",
    subtitle: "パーソナルトレーニング",
    title: "PERSONAL TRAINING",
    image: "https://raw.githubusercontent.com/reolch/Resource_TRIGGER_HOMEPAGE/refs/heads/main/program_list_page/program-list-page-1.jpg",
    description:
      "プロのトレーナーがお客様のニーズに合わせたオリジナルメニューをご提案。お客様に合わせた多種多様なメニューをご用意しております。一人ひとりの目標や体調に合わせて、最適なトレーニングプログラムを組み立てます。筋力アップ、ダイエット、姿勢改善など、様々な目的に対応いたします。",
    subProgram: {
      title: "パーソナルジム",
      subtitle: "個別指導で効果的に鍛える",
      description:
        "マンツーマンでの指導により、正しいフォームを身につけながら効率的にトレーニングを行えます。初心者の方でも安心して始められるよう、丁寧にサポートいたします。",
    },
    href: "/program/personal-gym",
  },
  {
    id: "seitai",
    subtitle: "整体",
    title: "SEITAI",
    image: "https://raw.githubusercontent.com/reolch/Resource_TRIGGER_HOMEPAGE/refs/heads/main/program_list_page/program-list-page-2.jpg",
    description:
      "医師からも推薦を頂く整体施術。厚生労働省公認の国家資格保有者のみが在籍しております。身体の歪みを整え、痛みや不調を改善します。慢性的な肩こり、腰痛、頭痛など、様々な症状に対応いたします。",
    subProgram: {
      title: "整体施術",
      subtitle: "身体のバランスを整える",
      description:
        "骨格の歪みを矯正し、筋肉の緊張をほぐすことで、身体本来の機能を回復させます。リラックス効果も高く、心身ともにリフレッシュできます。",
    },
    href: "/program/seitai",
  },
  {
    id: "esthetic",
    subtitle: "エステ",
    title: "ESTHETIC",
    image: "https://raw.githubusercontent.com/reolch/Resource_TRIGGER_HOMEPAGE/refs/heads/main/program_list_page/program-list-page-3.jpg",
    description:
      "美しい肌と身体を目指すエステティックサロン。プロのエステティシャンが、お客様の肌質や悩みに合わせた施術をご提供いたします。フェイシャル、ボディケア、リラクゼーションなど、様々なメニューをご用意しております。",
    subProgram: {
      title: "フェイシャルエステ",
      subtitle: "美しい肌を目指す",
      description:
        "お肌の状態を丁寧にカウンセリングし、最適なケアをご提案いたします。保湿、美白、アンチエイジングなど、お客様のご希望に合わせた施術を行います。",
    },
    href: "/program/esthetic",
  },
]

export default function ProgramPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header variant="dark" />

      {/* Hero Banner */}
      <section className="relative h-[400px] lg:h-[500px]">
        <Image
          src="/program-hero-yoga-women-class.jpg"
          alt="プログラム"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-[#5a6a6e]/40" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center">
          <p className="text-sm tracking-[0.3em] mb-2">プログラム</p>
          <h1 className="text-4xl lg:text-5xl tracking-[0.2em] font-light">
            PROGRAM
          </h1>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden md:flex flex-col z-20">
          <a
            href="tel:070-0000-0000"
            className="bg-[#2a68a4] hover:bg-[#3d83c7] transition-colors text-white text-sm tracking-wider flex items-center justify-center"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "160px",
            }}
          >
            電話で予約する
          </a>
          {/* <Link
            href="https://line.me/R/ti/p/@841ytgtf"
            className="bg-[#00c300] hover:bg-[#10e310] transition-colors text-white text-sm tracking-wider flex items-center justify-center"
            style={{
              writingMode: "vertical-rl",
              width: "70px",
              height: "240px",
            }}
          >
            公式ラインで予約する
          </Link> */}
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-20 lg:py-28 px-4">
        <div className="max-w-[930px] mx-auto text-center">
          <p className="text-[#c4a47c] text-lg tracking-[0.3em] mb-4">
            パーソナルトレーニング＆整体＆エステ
          </p>
          <h2 className="text-2xl lg:text-3xl text-[#3d4a4f] tracking-[0.2em] mb-8">
            カラダとココロを鍛える
          </h2>
          <p className="text-[#666] leading-relaxed text-sm lg:text-base">
            基礎から高度なコア強化や柔軟性アップまで、段階的に学べるコースをご用意。
            <br className="hidden lg:block" />
            初心者から経験者まで無理なく継続できるので、ご自身にあったペースで健康的な身体を目指せます。
          </p>
        </div>
      </section>

      {/* Program Cards */}
      <section className="pb-20 lg:pb-28 px-4">
        <div className="max-w-[900px] mx-auto space-y-16">
          {programs.map((program, index) => (
            <article
              key={program.id}
              className="bg-white border border-gray-100 shadow-sm"
            >
              <div className="relative h-[250px] lg:h-[380px] overflow-hidden">
                <Image
                  src={program.image || "/placeholder.svg"}
                  alt={program.title}
                  fill
                  className="object-cover"
                  priority={index < 2}
                />
              </div>

              <div className="p-8 lg:p-12 text-center">
                <p className="text-[#666] text-sm mb-2">{program.subtitle}</p>
                <h3 className="text-3xl lg:text-4xl text-[#c4a47c] tracking-[0.15em] mb-6">
                  {program.title}
                </h3>
                <p className="text-[#666] text-sm lg:text-base leading-relaxed mb-8 max-w-[700px] mx-auto">
                  {program.description}
                </p>

                <div className="border-t border-gray-200 pt-8 mt-8 text-left">
                  <div className="flex items-center gap-3 mb-3">
                    <h4 className="text-lg text-[#3d4a4f] font-medium">
                      {program.subProgram.title}
                    </h4>
                    <span className="text-[#c4a47c] text-sm">
                      {program.subProgram.subtitle}
                    </span>
                  </div>
                  <p className="text-[#666] text-sm leading-relaxed">
                    {program.subProgram.description}
                  </p>
                </div>

                <Link
                  href={program.href}
                  className="inline-flex items-center justify-center gap-2 mt-10 px-12 py-4 bg-[#6b7c7f] text-white text-sm tracking-wider hover:bg-[#5a6a6e] transition-colors"
                >
                  もっと見る
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <CTABanner />
      <Footer />
    </div>
  )
}
